package com.s25.dnstile;

import android.app.PendingIntent;
import android.content.Intent;
import android.database.ContentObserver;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.service.quicksettings.Tile;
import android.service.quicksettings.TileService;
import android.widget.Toast;

/** One tap: selected DNS-over-TLS host <-> Android Automatic mode. */
public final class DnsTileService extends TileService {
    private ContentObserver observer;

    @Override public void onTileAdded() {
        super.onTileAdded();
        refresh();
    }

    @Override public void onStartListening() {
        super.onStartListening();
        if (observer == null) {
            observer = new ContentObserver(new Handler(Looper.getMainLooper())) {
                @Override public void onChange(boolean selfChange) { refresh(); }
            };
            getContentResolver().registerContentObserver(
                    Settings.Global.getUriFor(DnsControl.KEY_MODE), false, observer);
            getContentResolver().registerContentObserver(
                    Settings.Global.getUriFor(DnsControl.KEY_HOST), false, observer);
        }
        refresh();
    }

    @Override public void onStopListening() {
        if (observer != null) {
            getContentResolver().unregisterContentObserver(observer);
            observer = null;
        }
        super.onStopListening();
    }

    @Override public void onClick() {
        super.onClick();
        if (!DnsControl.hasPermission(this)) {
            launchSetup();
            return;
        }
        try {
            if (DnsControl.enabled(this)) { DnsControl.setAutomatic(this); DnsHistory.record(this,"Выключен → Автоматически",false); }
            else if (DnsPrefs.selected(this) == null) {
                Toast.makeText(this, "Добавь DNS в DNS Switch", Toast.LENGTH_LONG).show();
                launchSetup();
                return;
            } else { DnsControl.setSelectedOn(this); DnsHistory.record(this,"Включён: "+DnsPrefs.name(this),true); }
        } catch (Exception ex) {
            Toast.makeText(this, ex.getMessage(), Toast.LENGTH_LONG).show();
            launchSetup();
        }
        refresh();
    }

    private void launchSetup() {
        Intent intent = new Intent(this, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        try {
            if (Build.VERSION.SDK_INT >= 34) {
                PendingIntent pi = PendingIntent.getActivity(this, 14, intent,
                        PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
                startActivityAndCollapse(pi);
            } else {
                startActivityAndCollapse(intent);
            }
        } catch (Exception ignored) {
            Toast.makeText(this, "Откройте DNS Switch и выдайте разрешение ADB",
                    Toast.LENGTH_LONG).show();
        }
    }

    private void refresh() {
        Tile tile = getQsTile();
        if (tile == null) return;
        boolean permitted = DnsControl.hasPermission(this);
        boolean active = permitted && DnsControl.enabled(this);
        tile.setState(active ? Tile.STATE_ACTIVE : Tile.STATE_INACTIVE);
        tile.setLabel("DNS • ИИ");
        tile.setContentDescription(active ? "Выбранный DNS включён, нажмите для автоматического режима" :
                "Автоматический DNS, нажмите для выбранного сервера");
        if (Build.VERSION.SDK_INT >= 29) {
            tile.setSubtitle(!permitted ? "Требуется настройка" :
                    active ? DnsControl.status(this) : DnsControl.status(this));
        }
        tile.updateTile();
    }
}
