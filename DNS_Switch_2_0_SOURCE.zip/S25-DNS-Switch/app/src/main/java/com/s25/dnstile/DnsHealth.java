package com.s25.dnstile;

import android.os.SystemClock;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.HttpURLConnection;
import java.net.URL;
import javax.net.ssl.SSLParameters;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;

/** A verified TCP+TLS connection to a DNS-over-TLS server, NOT a DNS query or a region test. */
public final class DnsHealth {
    public static final class Result {
        public final String host;
        public final long durationMs;
        public final String error;
        Result(String h, long d, String e) { host=h; durationMs=d; error=e; }
        public boolean ok() { return error == null; }
    }
    private DnsHealth() { }
    public static Result checkDot(String hostname) {
        String host;
        try { host=DnsControl.validateHost(hostname); }
        catch (Exception ex) { return new Result(hostname,-1,"Неверный адрес"); }
        long started = SystemClock.elapsedRealtime();
        try (Socket raw = new Socket()) {
            raw.connect(new InetSocketAddress(host,853), 2700);
            raw.setSoTimeout(2700);
            try (SSLSocket socket=(SSLSocket) SSLSocketFactory.getDefault().createSocket(raw,host,853,true)) {
                socket.setSoTimeout(2700);
                SSLParameters params=socket.getSSLParameters();
                params.setEndpointIdentificationAlgorithm("HTTPS");
                socket.setSSLParameters(params);
                socket.startHandshake();
                return new Result(host,SystemClock.elapsedRealtime()-started,null);
            }
        } catch (Exception ex) {
            return new Result(host,-1,"Не удалось установить защищённое TLS-соединение");
        }
    }
    public static String checkHttps(String host) {
        HttpURLConnection c=null;
        try {
            c=(HttpURLConnection)new URL("https://"+host+"/").openConnection();
            c.setRequestMethod("HEAD");
            c.setConnectTimeout(3500); c.setReadTimeout(3500);
            c.setInstanceFollowRedirects(false);
            c.setRequestProperty("User-Agent","DNS-Switch/2.0");
            int code=c.getResponseCode();
            return code < 400 ? "HTTPS отвечает ("+code+")" : "Ответ HTTPS: "+code;
        } catch (Exception ex) { return "Нет ответа HTTPS"; }
        finally { if (c!=null) c.disconnect(); }
    }
}
