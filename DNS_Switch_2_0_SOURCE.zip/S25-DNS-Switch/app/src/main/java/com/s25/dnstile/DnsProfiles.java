package com.s25.dnstile;

import android.content.Context;
import android.content.SharedPreferences;

/** Named, manually activated Private DNS profiles. They do not route DNS per application. */
public final class DnsProfiles {
    private static final String FILE="dns_switch_profiles";
    public static final String[] IDS={"usual","ai","work","home","mobile"};
    public static final String[] NAMES={"Стандартный","ИИ","Рабочий","Домашний Wi-Fi","Мобильная сеть"};
    private DnsProfiles(){}
    private static SharedPreferences p(Context c){return c.getSharedPreferences(FILE,Context.MODE_PRIVATE);}
    public static String assigned(Context c,int index){return p(c).getString(IDS[index],"");}
    public static void assign(Context c,int index,String dnsId){p(c).edit().putString(IDS[index],dnsId).apply();}
    public static String active(Context c){return p(c).getString("active","");}
    public static void setActive(Context c,String profileId){p(c).edit().putString("active",profileId).apply();}
}
