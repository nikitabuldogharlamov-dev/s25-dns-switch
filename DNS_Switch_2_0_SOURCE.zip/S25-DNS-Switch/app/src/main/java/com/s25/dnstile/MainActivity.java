package com.s25.dnstile;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.StatusBarManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ComponentName;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.SweepGradient;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.Icon;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.os.VibratorManager;
import android.text.Editable;
import android.text.InputType;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Switch;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** DNS Switch 2.0: native dark UI, functional diagnostics, manual DNS profiles, honest TLS testing. */
public final class MainActivity extends Activity {
    // Deliberately restrained One UI-inspired palette, not the neon concept collage.
    private static final int BG=Color.rgb(8,9,13);
    private static final int CARD=Color.rgb(29,30,36);
    private static final int CARD_HIGHLIGHT=Color.rgb(43,42,57);
    private static final int SURFACE=Color.rgb(37,38,45);
    private static final int WHITE=Color.rgb(250,249,254);
    private static final int MUTED=Color.rgb(164,164,176);
    private static final int PURPLE=Color.rgb(174,155,255);
    private static final int ACCENT=Color.rgb(113,90,240);
    private static final int GREEN=Color.rgb(113,220,171);
    private static final int RED=Color.rgb(255,151,151);
    private static final int BLUE=Color.rgb(113,167,255);
    private static final String ADB="adb shell pm grant com.s25.dnstile android.permission.WRITE_SECURE_SETTINGS";
    private static final int HOME=0, DNS=1, TOOLS=2, SETTINGS=3,
            TEST=4, SMART=5, DIAG=6, PROFILES=7, STATS=8, AI=9, ABOUT=10;

    private final ExecutorService executor=Executors.newFixedThreadPool(3);
    private final Map<String,DnsHealth.Result> checks=new HashMap<>();
    private int page=HOME;
    private LinearLayout root;
    private LinearLayout body;
    private ShizukuGrant shizuku;
    private boolean checkingAll=false;

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().getDecorView().setSystemUiVisibility(0);
        if(saved!=null)page=saved.getInt("page",HOME);
        shizuku=new ShizukuGrant(this,(success,message)-> { toast(message);render(); });
        render();
    }
    @Override protected void onSaveInstanceState(Bundle b){b.putInt("page",page);super.onSaveInstanceState(b);}
    @Override protected void onResume(){super.onResume();if(root!=null)render();}
    @Override protected void onDestroy(){if(shizuku!=null)shizuku.release();executor.shutdownNow();super.onDestroy();}
    @Override public void onBackPressed(){if(page==HOME)super.onBackPressed();else navigate(page>=TEST ? TOOLS : HOME);}

    private SharedPreferences preferences(){return getSharedPreferences("dns_switch_ui_v2",MODE_PRIVATE);}
    private boolean option(String key,boolean defaultValue){return preferences().getBoolean(key,defaultValue);}
    private void setOption(String key,boolean enabled){preferences().edit().putBoolean(key,enabled).apply();}
    private boolean favorite(String id){return option("fav_"+id,false);}

    private void render(){
        root=column();root.setBackgroundColor(BG);setContentView(root);
        topBar();
        ScrollView sc=new ScrollView(this);sc.setFillViewport(true);sc.setVerticalScrollBarEnabled(false);
        body=column();body.setPadding(dp(22),dp(12),dp(22),dp(40));
        sc.addView(body,new ScrollView.LayoutParams(-1,-2));
        root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        switch(page){
            case HOME: home();break;
            case DNS: dns();break;
            case TOOLS: tools();break;
            case SETTINGS: settings();break;
            case TEST: test();break;
            case SMART: smart();break;
            case DIAG: diagnostics();break;
            case PROFILES: profiles();break;
            case STATS: statistics();break;
            case AI: ai();break;
            default: about();
        }
        bottomBar();
        DnsControl.notifyTile(this);
    }
    private void topBar(){
        LinearLayout r=row();r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(dp(22),dp(11),dp(22),dp(9));
        if(page>=TEST){
            TextView back=text("‹",32,WHITE,false);back.setGravity(Gravity.CENTER);
            back.setContentDescription("Назад");r.addView(back,new LinearLayout.LayoutParams(dp(44),dp(43)));
            back.setOnClickListener(v->navigate(TOOLS));
        } else {
            TextView mark=text("ИИ✦",12,WHITE,true);mark.setGravity(Gravity.CENTER);
            GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{BLUE,ACCENT});g.setCornerRadius(dp(12));mark.setBackground(g);
            r.addView(mark,new LinearLayout.LayoutParams(dp(36),dp(36)));
        }
        TextView label=text("DNS Switch",17,WHITE,true);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1);lp.leftMargin=dp(12);r.addView(label,lp);
        TextView settings=text("⚙",23,MUTED,false);settings.setGravity(Gravity.CENTER);
        settings.setContentDescription("Настройки");r.addView(settings,new LinearLayout.LayoutParams(dp(42),dp(43)));
        settings.setOnClickListener(v->navigate(SETTINGS));
        root.addView(r);
    }
    private void heading(String title,String caption){
        add(text(title,32,WHITE,true),dp(10));
        if(caption!=null&&!caption.isEmpty())add(text(caption,14,MUTED,false),dp(8));
    }
    private void section(String title){add(text(title,17,WHITE,true),dp(28));}

    private void home(){
        heading("Управление DNS","Частный DNS вашего телефона");
        boolean enabled=DnsControl.enabled(this);
        boolean permission=DnsControl.hasPermission(this);
        LinearLayout hero=column();hero.setGravity(Gravity.CENTER_HORIZONTAL);
        addIn(hero,new View(this),dp(8));
        PowerOrb orb=new PowerOrb(enabled);orb.setContentDescription(enabled?"Выключить DNS":"Включить DNS");
        hero.addView(orb,new LinearLayout.LayoutParams(dp(184),dp(184)));
        orb.setOnClickListener(v->toggle());
        TextView state=text(enabled?"Включено":"Выключено",26,enabled?WHITE:MUTED,true);
        state.setGravity(Gravity.CENTER);addIn(hero,state,0);
        TextView sub=text(enabled?"Используется выбранный DNS":"Системный режим «Автоматически»",13,MUTED,false);
        sub.setGravity(Gravity.CENTER);addIn(hero,sub,dp(5));
        add(hero,dp(12));

        DnsPrefs.Entry selected=DnsPrefs.selected(this);
        LinearLayout current=card();
        addIn(current,text("ТЕКУЩИЙ DNS",11,MUTED,true),0);
        LinearLayout r=row();r.setGravity(Gravity.CENTER_VERTICAL);
        badge(r,"✦",PURPLE);
        LinearLayout info=column();
        info.addView(text(selected==null?"Выберите сервер":selected.label,17,WHITE,true));
        TextView host=text(selected==null?"Добавьте DNS в список":selected.host,12,MUTED,false);
        host.setSingleLine(true);host.setEllipsize(TextUtils.TruncateAt.END);addIn(info,host,dp(4));
        LinearLayout.LayoutParams w=new LinearLayout.LayoutParams(0,-2,1);w.leftMargin=dp(12);r.addView(info,w);
        r.addView(text("›",27,MUTED,false));addIn(current,r,dp(12));
        current.setOnClickListener(v->navigate(DNS));
        add(current,dp(27));

        if(!permission){
            LinearLayout notice=card();
            notice.addView(text("Требуется разрешение Shizuku",16,WHITE,true));
            addIn(notice,text("Разрешите изменение Private DNS один раз в настройках.",13,MUTED,false),dp(9));
            Button b=button("Настроить разрешение",true);addIn(notice,b,dp(12));b.setOnClickListener(v->navigate(SETTINGS));
            add(notice,dp(12));
        }
        section("Быстрые действия");
        LinearLayout row1=row();
        action(row1,"✦","Быстрый выбор",()->navigate(SMART));
        action(row1,"◉","Проверить DNS",()->navigate(TEST));
        add(row1,dp(14));
        LinearLayout row2=row();
        action(row2,"▥","Статистика",()->navigate(STATS));
        action(row2,"ⓘ","Диагностика",()->navigate(DIAG));
        add(row2,dp(12));
        add(text("DNS-over-TLS шифрует DNS-запросы, но не меняет ваш IP-адрес и страну аккаунта.",12,MUTED,false),dp(22));
    }
    private void action(LinearLayout parent,String symbol,String title,Runnable onClick){
        LinearLayout b=column();b.setPadding(dp(15),dp(17),dp(12),dp(17));b.setBackground(round(CARD,22));
        b.addView(text(symbol,26,PURPLE,true));addIn(b,text(title,13,WHITE,true),dp(12));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(112),1);lp.rightMargin=dp(6);
        parent.addView(b,lp);b.setOnClickListener(v->onClick.run());
    }

    private void dns(){
        heading("Список DNS","Ваши серверы DNS-over-TLS");
        LinearLayout header=row();header.setGravity(Gravity.CENTER_VERTICAL);
        TextView count=text("Серверов: "+DnsPrefs.entries(this).size(),13,MUTED,false);
        header.addView(count,new LinearLayout.LayoutParams(0,-2,1));
        Button add=button("＋ Добавить",true);header.addView(add,new LinearLayout.LayoutParams(dp(135),dp(48)));
        add.setOnClickListener(v->editDns(null));add(header,dp(22));
        EditText search=field("Поиск по названию или адресу","");
        search.setSingleLine(true);add(search,dp(18));
        LinearLayout listing=column();add(listing,dp(10));
        fillDns(listing,"");
        search.addTextChangedListener(new TextWatcher(){
            public void beforeTextChanged(CharSequence s,int a,int c,int f){}
            public void onTextChanged(CharSequence s,int start,int before,int count){fillDns(listing,s.toString());}
            public void afterTextChanged(Editable e){}
        });
        add(text("Используйте имя сервера, например dns.google, а не IPv4-адрес или URL.",12,MUTED,false),dp(20));
    }
    private void fillDns(LinearLayout out,String filter){
        out.removeAllViews();
        List<DnsPrefs.Entry> items=new ArrayList<>(DnsPrefs.entries(this));
        items.sort((a,b)->Boolean.compare(favorite(b.id),favorite(a.id)));
        DnsPrefs.Entry selected=DnsPrefs.selected(this);
        int found=0;
        for(DnsPrefs.Entry e:items){
            if(!e.label.toLowerCase().contains(filter.toLowerCase())&&!e.host.toLowerCase().contains(filter.toLowerCase()))continue;
            found++;
            boolean chosen=selected!=null&&selected.id.equals(e.id);
            LinearLayout box=card();
            LinearLayout row=row();row.setGravity(Gravity.CENTER_VERTICAL);
            TextView mark=text(chosen?"✓":"◈",22,chosen?PURPLE:MUTED,true);
            mark.setGravity(Gravity.CENTER);mark.setBackground(round(SURFACE,13));
            row.addView(mark,new LinearLayout.LayoutParams(dp(46),dp(46)));
            LinearLayout title=column();
            title.addView(text(e.label,15,WHITE,true));
            TextView host=text(e.host,12,MUTED,false);host.setSingleLine();host.setEllipsize(TextUtils.TruncateAt.END);
            addIn(title,host,dp(4));
            LinearLayout.LayoutParams d=new LinearLayout.LayoutParams(0,-2,1);d.leftMargin=dp(12);row.addView(title,d);
            TextView fav=text(favorite(e.id)?"★":"☆",25,favorite(e.id)?PURPLE:MUTED,false);
            fav.setPadding(dp(5),dp(5),dp(5),dp(5));row.addView(fav);
            fav.setContentDescription("В избранное: "+e.label);
            fav.setOnClickListener(v->{setOption("fav_"+e.id,!favorite(e.id));fillDns(out,filter);});
            TextView more=text("⋮",24,MUTED,true);more.setGravity(Gravity.CENTER);
            row.addView(more,new LinearLayout.LayoutParams(dp(32),dp(44)));
            more.setContentDescription("Редактировать "+e.label);
            more.setOnClickListener(v->editDns(e));
            box.addView(row);
            row.setOnClickListener(v->select(e));
            if(chosen)addIn(box,text("ВЫБРАН",10,PURPLE,true),dp(10));
            DnsHealth.Result result=checks.get(e.host);
            if(result!=null)addIn(box,text(result.ok()?"TLS-подключение: "+result.durationMs+" мс":"TLS: недоступен",12,result.ok()?GREEN:RED,false),dp(8));
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.topMargin=dp(9);out.addView(box,lp);
        }
        if(found==0)addIn(out,text("Ничего не найдено",15,MUTED,false),dp(18));
    }

    private void tools(){
        heading("Инструменты","Проверка и управление подключением");
        toolCard("◎","Проверка DNS","Реальный отклик защищённого TLS-сервера",TEST);
        toolCard("✦","Умный выбор","Сравнить ваши серверы и выбрать лучший",SMART);
        toolCard("◈","Диагностика","Режим Android, разрешения и соединение",DIAG);
        toolCard("✧","Профили DNS","Быстрые наборы для разных сценариев",PROFILES);
        toolCard("▥","Статистика","Время работы и история переключений",STATS);
        toolCard("✳","ИИ-сервисы","Проверка HTTPS ChatGPT, Gemini и Claude",AI);
    }
    private void toolCard(String icon,String name,String summary,int target){
        LinearLayout b=card();LinearLayout r=row();r.setGravity(Gravity.CENTER_VERTICAL);
        badge(r,icon,PURPLE);
        LinearLayout mid=column();mid.addView(text(name,16,WHITE,true));addIn(mid,text(summary,12,MUTED,false),dp(5));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1);lp.leftMargin=dp(13);r.addView(mid,lp);
        r.addView(text("›",28,MUTED,false));b.addView(r);
        b.setOnClickListener(v->navigate(target));add(b,dp(12));
    }

    private void test(){
        heading("Проверка DNS","Подключение к DNS-over-TLS на порту 853");
        DnsPrefs.Entry selected=DnsPrefs.selected(this);
        if(selected==null){add(text("Добавьте DNS для проверки",16,MUTED,false),dp(25));return;}
        LinearLayout current=card();
        current.addView(text(selected.label,20,WHITE,true));
        addIn(current,text(selected.host,13,MUTED,false),dp(6));
        add(current,dp(23));
        LinearLayout result=card();
        TextView big=text("—",42,PURPLE,true);big.setGravity(Gravity.CENTER);result.addView(big);
        TextView status=text("Нажмите «Проверить»",14,MUTED,false);status.setGravity(Gravity.CENTER);
        addIn(result,status,dp(8));add(result,dp(13));
        Button go=button("Проверить соединение",true);
        go.setOnClickListener(v->{
            go.setEnabled(false);big.setText("…");status.setText("Подключаемся к серверу…");
            runBg(()->{
                DnsHealth.Result r=DnsHealth.checkDot(selected.host);
                runOnUiThread(()->{if(isDestroyed())return;checks.put(selected.host,r);go.setEnabled(true);
                    big.setText(r.ok()?r.durationMs+" мс":"Нет связи");
                    status.setText(r.ok()?"Шифрованное TLS-соединение успешно":"Не удалось установить TLS на порту 853");
                    big.setTextColor(r.ok()?GREEN:RED);
                });
            });
        });
        add(go,dp(19));
        add(text("Замер включает поиск имени, TCP и TLS-рукопожатие. Это не время DNS-запроса и не гарантия работы заблокированных сайтов или приложений.",13,MUTED,false),dp(19));
    }
    private void smart(){
        heading("Умный выбор","Измерение соединения с вашими DNS");
        LinearLayout results=column();add(results,dp(20));
        TextView progress=text("Нажмите «Сравнить серверы»",14,MUTED,false);
        add(progress,dp(14));
        Button run=button("Сравнить серверы",true);
        run.setOnClickListener(v->{
            if(checkingAll){toast("Проверка уже выполняется");return;}
            List<DnsPrefs.Entry> entries=DnsPrefs.entries(this);
            if(entries.isEmpty()){toast("Добавьте серверы DNS");return;}
            checkingAll=true;run.setEnabled(false);results.removeAllViews();
            progress.setText("Проверяем "+entries.size()+" серверов…");
            runBg(()->{
                List<DnsHealth.Result> measured=new ArrayList<>();
                Map<String,DnsPrefs.Entry> byHost=new HashMap<>();
                for(DnsPrefs.Entry e:entries){
                    if(Thread.currentThread().isInterrupted())break;
                    DnsHealth.Result r=DnsHealth.checkDot(e.host);measured.add(r);byHost.put(e.host,e);
                    runOnUiThread(()->{if(!isDestroyed())progress.setText("Проверено: "+measured.size()+" из "+entries.size());});
                }
                measured.sort((a,b)->{
                    if(a.ok()!=b.ok())return a.ok()?-1:1;
                    return Long.compare(a.durationMs,b.durationMs);
                });
                runOnUiThread(()->{
                    checkingAll=false;if(isDestroyed())return;
                    run.setEnabled(true);results.removeAllViews();
                    DnsHealth.Result best=null;
                    for(DnsHealth.Result r:measured){
                        checks.put(r.host,r);
                        DnsPrefs.Entry e=byHost.get(r.host);
                        if(e==null)continue;
                        if(r.ok()&&best==null)best=r;
                        LinearLayout item=card();
                        item.addView(text(e.label,16,WHITE,true));
                        addIn(item,text(r.ok()?r.durationMs+" мс · TLS доступен":"TLS недоступен",14,r.ok()?GREEN:RED,false),dp(7));
                        addIn(results,item,dp(9));
                    }
                    if(best==null){progress.setText("Ни один сервер не ответил по TLS на порту 853");return;}
                    DnsPrefs.Entry choice=byHost.get(best.host);
                    progress.setText("Лучшее измеренное соединение: "+choice.label);
                    Button apply=button("Выбрать «"+choice.label+"»",true);
                    addIn(results,apply,dp(15));apply.setOnClickListener(v2->select(choice));
                });
            });
        });
        add(run,dp(16));
        add(text("Сравнение происходит последовательно, результаты зависят от сети. «Лучший» означает минимальное время установки TLS-соединения, а не скорость всего интернета.",12,MUTED,false),dp(18));
    }
    private void diagnostics(){
        heading("Диагностика","Что действительно настроено в Android");
        property("Системный режим",DnsControl.currentMode(this).equals("hostname")?"Частный DNS — вручную":DnsControl.status(this));
        property("Текущий DNS",DnsControl.status(this));
        property("Выбранный в приложении",DnsPrefs.name(this));
        property("Разрешение WRITE_SECURE_SETTINGS",DnsControl.hasPermission(this)?"Предоставлено":"Не предоставлено");
        LinearLayout c=card();
        c.addView(text("Проверка доступности",17,WHITE,true));
        addIn(c,text("Проверьте выбранный DNS-over-TLS и доступ к HTTPS-сервисам. Эти проверки не определяют регион Google Play.",13,MUTED,false),dp(8));
        Button dns=button("Проверить DNS",false);addIn(c,dns,dp(14));dns.setOnClickListener(v->navigate(TEST));
        Button apps=button("Проверить ИИ-сервисы",false);addIn(c,apps,dp(9));apps.setOnClickListener(v->navigate(AI));
        add(c,dp(14));
        add(text("Private DNS сам по себе не меняет внешний IP-адрес, страну Google Play или географические ограничения Gemini.",13,MUTED,false),dp(20));
    }
    private void property(String name,String value){
        LinearLayout p=card();p.addView(text(name,12,MUTED,false));
        addIn(p,text(value,17,WHITE,true),dp(7));add(p,dp(11));
    }

    private void profiles(){
        heading("Профили DNS","Профили переключаются вручную");
        for(int i=0;i<DnsProfiles.IDS.length;i++){
            final int index=i;
            String assigned=DnsProfiles.assigned(this,i);
            DnsPrefs.Entry entry=findEntry(assigned);
            LinearLayout b=card();
            LinearLayout r=row();r.setGravity(Gravity.CENTER_VERTICAL);
            badge(r,i==1?"✦":i==3?"⌂":"◈",i==1?PURPLE:BLUE);
            LinearLayout mid=column();mid.addView(text(DnsProfiles.NAMES[i],17,WHITE,true));
            addIn(mid,text(entry==null?"Сервер не назначен":entry.label,12,MUTED,false),dp(5));
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1);lp.leftMargin=dp(12);r.addView(mid,lp);
            TextView mark=text(DnsProfiles.IDS[i].equals(DnsProfiles.active(this))?"✓":"⋮",22,PURPLE,true);
            mark.setGravity(Gravity.CENTER);r.addView(mark,new LinearLayout.LayoutParams(dp(42),dp(44)));
            b.addView(r);
            b.setOnClickListener(v->profileDialog(index));
            add(b,dp(11));
        }
        add(text("Профиль хранит выбранный DNS-сервер. Это НЕ раздельный DNS для приложений, и выбор профиля сам по себе не меняет сетевой маршрут.",13,MUTED,false),dp(21));
    }
    private DnsPrefs.Entry findEntry(String id){for(DnsPrefs.Entry e:DnsPrefs.entries(this))if(e.id.equals(id))return e;return null;}
    private void profileDialog(int index){
        List<DnsPrefs.Entry> entries=DnsPrefs.entries(this);
        if(entries.isEmpty()){toast("Добавьте DNS-сервер");navigate(DNS);return;}
        String[] names=new String[entries.size()];int current=-1;
        for(int j=0;j<entries.size();j++){names[j]=entries.get(j).label+"\n"+entries.get(j).host;
            if(entries.get(j).id.equals(DnsProfiles.assigned(this,index)))current=j;}
        new AlertDialog.Builder(this).setTitle(DnsProfiles.NAMES[index]+" · выбор DNS")
                .setSingleChoiceItems(names,current,(d,which)->{
                    DnsPrefs.Entry e=entries.get(which);
                    DnsProfiles.assign(this,index,e.id);
                    DnsProfiles.setActive(this,DnsProfiles.IDS[index]);
                    d.dismiss();select(e);
                }).setNegativeButton("Отмена",null).show();
    }
    private void statistics(){
        heading("Статистика","События DNS Switch на этом телефоне");
        LinearLayout metrics=row();
        LinearLayout time=card();time.addView(text("Время включения",12,MUTED,false));
        long total=DnsHistory.duration(this)/60000L;
        addIn(time,text((total/60)+" ч "+(total%60)+" мин",22,WHITE,true),dp(8));
        metrics.addView(time,new LinearLayout.LayoutParams(0,-2,1));
        LinearLayout count=card();count.addView(text("Действий",12,MUTED,false));
        addIn(count,text(String.valueOf(DnsHistory.count(this)),22,WHITE,true),dp(8));
        LinearLayout.LayoutParams ml=new LinearLayout.LayoutParams(0,-2,1);ml.leftMargin=dp(10);metrics.addView(count,ml);
        add(metrics,dp(22));
        section("История переключений");
        List<String> events=DnsHistory.events(this);
        if(events.isEmpty())add(text("Пока нет событий. История начнёт записываться после первого переключения.",13,MUTED,false),dp(18));
        for(String event:events){LinearLayout c=card();c.addView(text(event,13,WHITE,false));add(c,dp(8));}
        add(text("Данные собираются локально с версии 2.0. Время учитывает переключения из приложения и его кнопки в шторке. Действия других приложений могут не учитываться.",12,MUTED,false),dp(20));
    }
    private void ai(){
        heading("ИИ-сервисы","Проверка HTTPS, не обход блокировки региона");
        String[][] sites={{"ChatGPT","chatgpt.com"},{"Gemini","gemini.google.com"},{"Claude","claude.ai"}};
        LinearLayout list=column();add(list,dp(20));
        for(String[] site:sites){
            LinearLayout c=card();
            c.addView(text(site[0],18,WHITE,true));
            TextView status=text(site[1]+" · не проверялся",13,MUTED,false);addIn(c,status,dp(8));
            Button check=button("Проверить HTTPS",false);
            addIn(c,check,dp(12));
            check.setOnClickListener(v->{
                check.setEnabled(false);status.setText("Проверяем сеть…");
                runBg(()->{
                    String result=DnsHealth.checkHttps(site[1]);
                    runOnUiThread(()->{if(isDestroyed())return;check.setEnabled(true);status.setText(result);});
                });
            });
            addIn(list,c,dp(11));
        }
        add(text("Ответ HTTPS показывает только доступность веб-адреса. Он НЕ подтверждает, что Gemini или другое приложение доступно в регионе, что пройдена авторизация или что работает API.",13,MUTED,false),dp(21));
    }

    private void settings(){
        heading("Настройки","Управление приложением");
        section("Подключение");
        LinearLayout p=card();boolean allowed=DnsControl.hasPermission(this);
        p.addView(text(allowed?"✓  Разрешение предоставлено":"Shizuku · требуется разрешение",16,WHITE,true));
        addIn(p,text(allowed?"Изменять Private DNS можно без запущенного Shizuku":"Однократно выдайте WRITE_SECURE_SETTINGS",13,MUTED,false),dp(9));
        if(!allowed){
            Button grant=button("Разрешить через Shizuku",true);
            addIn(p,grant,dp(13));grant.setOnClickListener(v->shizuku.start());
            Button adb=button("Копировать команду ADB",false);addIn(p,adb,dp(9));
            adb.setOnClickListener(v->{ClipboardManager cm=(ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
                if(cm!=null)cm.setPrimaryClip(ClipData.newPlainText("ADB",ADB));toast("Команда скопирована");});
        }
        add(p,dp(13));
        LinearLayout tile=card();
        tile.addView(text("Значок ИИ✦ в шторке",16,WHITE,true));
        addIn(tile,text("Цвет плитки и яркость активного состояния определяет Samsung One UI.",13,MUTED,false),dp(8));
        Button add=button("Добавить кнопку DNS",false);addIn(tile,add,dp(12));add.setOnClickListener(v->addTile());
        add(tile,dp(12));
        section("Приложение");
        LinearLayout settings=card();
        settingSwitch(settings,"Тактильный отклик","Короткая вибрация при переключении","haptics",true);
        addIn(settings,new View(this),dp(9));
        settings.addView(text("Тёмная тема",16,WHITE,true));
        addIn(settings,text("AMOLED · оформление в духе One UI",13,MUTED,false),dp(5));
        add(settings,dp(12));
        Button about=button("О приложении и ограничениях   ›",false);add(about,dp(23));about.setOnClickListener(v->navigate(ABOUT));
    }
    private void settingSwitch(LinearLayout container,String title,String info,String key,boolean def){
        LinearLayout r=row();r.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout n=column();n.addView(text(title,16,WHITE,true));addIn(n,text(info,12,MUTED,false),dp(5));
        r.addView(n,new LinearLayout.LayoutParams(0,-2,1));
        Switch sw=new Switch(this);sw.setChecked(option(key,def));
        sw.setOnCheckedChangeListener((button,checked)->setOption(key,checked));
        r.addView(sw);container.addView(r);
    }
    private void about(){
        heading("DNS Switch","Версия 2.0");
        LinearLayout p=card();
        p.addView(text("Как работает приложение",18,WHITE,true));
        addIn(p,text("DNS Switch меняет системный Private DNS Android через разрешение WRITE_SECURE_SETTINGS. Корректно работает без VPN и root после однократной настройки Shizuku.",14,MUTED,false),dp(12));
        addIn(p,text("ВКЛ → выбранный hostname. ВЫКЛ → режим «Автоматически». Настройки DNS затрагивают системные запросы, а не отдельные ИИ-приложения.",14,MUTED,false),dp(12));
        addIn(p,text("Проверка DNS измеряет установление TLS-соединения на порту 853; это не тест фактического маршрута и не гарантия разблокировки Gemini.",14,MUTED,false),dp(12));
        add(p,dp(25));
        Button repo=button("GitHub проекта",false);add(repo,dp(15));
        repo.setOnClickListener(v->{try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("https://github.com/nikitabuldogharlamov-dev/s25-dns-switch")));}
            catch(Exception ex){toast("Не удалось открыть GitHub");}});
    }

    private void select(DnsPrefs.Entry entry){
        String old=DnsPrefs.selection(this);
        try{
            DnsPrefs.save(this,entry.id);
            if(DnsControl.hasPermission(this)&&DnsControl.enabled(this))DnsControl.setSelectedOn(this);
            DnsHistory.record(this,"Выбран: "+entry.label,DnsControl.enabled(this));
            toast("Выбран: "+entry.label);
        }catch(Exception ex){try{DnsPrefs.save(this,old);}catch(Exception ignored){}toast("Ошибка: "+ex.getMessage());}
        render();
    }
    private void toggle(){
        if(!DnsControl.hasPermission(this)){navigate(SETTINGS);toast("Сначала разрешите Shizuku");return;}
        try{
            if(DnsControl.enabled(this)){
                DnsControl.setAutomatic(this);
                DnsHistory.record(this,"Выключен → Автоматически",false);
            }else{
                if(DnsPrefs.selected(this)==null){navigate(DNS);toast("Добавьте DNS-сервер");return;}
                DnsControl.setSelectedOn(this);
                DnsHistory.record(this,"Включён: "+DnsPrefs.name(this),true);
            }
            haptic();
        }catch(Exception ex){toast("Ошибка: "+ex.getMessage());}
        render();
    }
    private void haptic(){if(!option("haptics",true))return;try{
        Vibrator v=getSystemService(Vibrator.class);if(v!=null && v.hasVibrator())v.vibrate(VibrationEffect.createOneShot(24,70));
    }catch(Exception ignored){}}

    private void editDns(DnsPrefs.Entry existing){
        boolean create=existing==null;
        LinearLayout form=column();form.setPadding(dp(20),dp(13),dp(20),dp(7));
        form.addView(text("НАЗВАНИЕ",12,MUTED,true));
        EditText name=field("Мой DNS",create?"":existing.label);addIn(form,name,dp(4));
        addIn(form,text("DNS-over-TLS HOSTNAME",12,MUTED,true),dp(18));
        EditText host=field("dns.example.com",create?"":existing.host);
        host.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_URI);
        addIn(form,host,dp(5));
        addIn(form,text("Только домен, без https://, порта и IP",12,MUTED,false),dp(6));
        AlertDialog.Builder builder=new AlertDialog.Builder(this)
                .setTitle(create?"Добавить DNS":"Редактировать DNS")
                .setView(form).setPositiveButton("Сохранить",null).setNegativeButton("Отмена",null);
        if(!create)builder.setNeutralButton("Удалить",(d,w)->deleteDns(existing));
        AlertDialog dialog=builder.create();
        dialog.setOnShowListener(v->{
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(PURPLE);
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v2->{
                try{
                    String hostname=DnsControl.validateHost(host.getText().toString());
                    DnsPrefs.Entry saved=DnsPrefs.upsert(this,create?null:existing.id,name.getText().toString(),hostname);
                    if(create)DnsPrefs.save(this,saved.id);
                    if(DnsControl.enabled(this)&&DnsControl.hasPermission(this)){
                        DnsPrefs.Entry selected=DnsPrefs.selected(this);
                        if(selected!=null&&selected.id.equals(saved.id))DnsControl.setSelectedOn(this);
                    }
                    dialog.dismiss();toast("Сохранено");render();
                }catch(IllegalArgumentException ex){host.setError(ex.getMessage());}
                catch(Exception ex){toast("Сохранено, но не применено: "+ex.getMessage());dialog.dismiss();render();}
            });
        });
        dialog.show();
    }
    private void deleteDns(DnsPrefs.Entry entry){
        new AlertDialog.Builder(this).setTitle("Удалить DNS?").setMessage(entry.label+"\n"+entry.host)
                .setNegativeButton("Отмена",null).setPositiveButton("Удалить",(d,w)->{
                    try{
                        DnsPrefs.Entry selected=DnsPrefs.selected(this);
                        if(selected!=null&&selected.id.equals(entry.id)&&DnsControl.enabled(this))DnsControl.setAutomatic(this);
                        DnsPrefs.delete(this,entry.id);
                        DnsHistory.record(this,"Удалён: "+entry.label,DnsControl.enabled(this));
                        toast("Удалено");render();
                    }catch(Exception ex){toast("Ошибка: "+ex.getMessage());}
                }).show();
    }
    private void addTile(){
        if(Build.VERSION.SDK_INT>=33){try{
            StatusBarManager mgr=getSystemService(StatusBarManager.class);
            if(mgr!=null){mgr.requestAddTileService(new ComponentName(this,DnsTileService.class),"DNS • ИИ",
                Icon.createWithResource(this,R.drawable.ic_dns_tile),getMainExecutor(),result->
                    toast(result==StatusBarManager.TILE_ADD_REQUEST_RESULT_TILE_ADDED?"Кнопка добавлена":"Откройте шторку → Изменить → DNS • ИИ"));return;}
        }catch(Exception ignored){}}
        toast("Откройте шторку → Изменить → DNS • ИИ");
    }
    private void bottomBar(){
        LinearLayout b=row();b.setGravity(Gravity.CENTER_VERTICAL);
        b.setPadding(dp(10),dp(8),dp(10),dp(13));
        b.setBackground(round(Color.rgb(19,19,24),24));
        String[] names={"Главная","DNS","Сервис","Настройки"};
        String[] symbols={"⌂","◎","▦","⚙"};
        for(int i=0;i<names.length;i++){
            int target=i;boolean picked=i==page||(page>=TEST && page!=ABOUT && i==TOOLS)||(page==ABOUT&&i==SETTINGS);
            LinearLayout cell=column();cell.setGravity(Gravity.CENTER);
            TextView ico=text(symbols[i],22,picked?PURPLE:MUTED,true);ico.setGravity(Gravity.CENTER);
            cell.addView(ico);addIn(cell,text(names[i],11,picked?WHITE:MUTED,false),dp(5));
            cell.setContentDescription(names[i]);
            b.addView(cell,new LinearLayout.LayoutParams(0,dp(57),1));
            cell.setOnClickListener(v->navigate(target));
        }
        root.addView(b);
    }
    private void navigate(int target){page=target;render();}
    private void toast(String message){Toast.makeText(this,message,Toast.LENGTH_SHORT).show();}
    private void runBg(Runnable job){try{executor.execute(job);}catch(Exception ignored){}}
    private LinearLayout column(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);return l;}
    private GradientDrawable round(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
    private LinearLayout card(){LinearLayout c=column();c.setPadding(dp(17),dp(18),dp(17),dp(18));c.setBackground(round(CARD,23));return c;}
    private TextView text(String s,int size,int color,boolean bold){
        TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);
        t.setLineSpacing(dp(2),1.02f);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;
    }
    private void badge(LinearLayout into,String label,int color){
        TextView symbol=text(label,23,color,true);symbol.setGravity(Gravity.CENTER);
        symbol.setBackground(round(SURFACE,14));into.addView(symbol,new LinearLayout.LayoutParams(dp(51),dp(51)));
    }
    private Button button(String title,boolean primary){
        Button b=new Button(this);b.setText(title);b.setAllCaps(false);
        b.setTextSize(14);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        b.setTextColor(primary?WHITE:WHITE);b.setBackground(round(primary?ACCENT:SURFACE,17));
        b.setMinimumHeight(dp(48));return b;
    }
    private EditText field(String hint,String value){
        EditText e=new EditText(this);e.setHint(hint);e.setText(value);
        e.setTextSize(15);e.setTextColor(WHITE);e.setHintTextColor(MUTED);
        e.setPadding(dp(16),dp(13),dp(16),dp(13));e.setBackground(round(SURFACE,15));
        return e;
    }
    private void add(View v,int top){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=top;body.addView(v,p);}
    private void addIn(LinearLayout l,View v,int top){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=top;l.addView(v,p);}
    private int dp(float d){return (int)(d*getResources().getDisplayMetrics().density+0.5f);}

    /** Sole glowing feature: only when enabled. Disabled: flat, low-contrast grey. */
    private final class PowerOrb extends View{
        private final boolean enabled;
        private final Paint pen=new Paint(Paint.ANTI_ALIAS_FLAG);
        PowerOrb(boolean state){super(MainActivity.this);enabled=state;setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
        @Override protected void onDraw(Canvas c){
            super.onDraw(c);
            float cx=getWidth()/2f,cy=getHeight()/2f,r=Math.min(getWidth(),getHeight())*.39f;
            pen.setStyle(Paint.Style.STROKE);pen.setStrokeCap(Paint.Cap.ROUND);
            pen.setStrokeWidth(dp(enabled?8:5));
            if(enabled){pen.setShader(new SweepGradient(cx,cy,new int[]{BLUE,ACCENT,PURPLE,BLUE},null));pen.setShadowLayer(dp(15),0,0,ACCENT);}
            else{pen.setShader(null);pen.clearShadowLayer();pen.setColor(Color.rgb(72,72,82));}
            c.drawCircle(cx,cy,r,pen);
            pen.clearShadowLayer();pen.setShader(null);pen.setStyle(Paint.Style.FILL);
            pen.setColor(enabled?Color.rgb(26,25,39):CARD);c.drawCircle(cx,cy,r-dp(6),pen);
            pen.setColor(enabled?WHITE:Color.rgb(121,121,132));pen.setStyle(Paint.Style.STROKE);
            pen.setStrokeWidth(dp(6));
            RectF rect=new RectF(cx-dp(22),cy-dp(22),cx+dp(22),cy+dp(22));
            c.drawArc(rect,-55,290,false,pen);c.drawLine(cx,cy-dp(29),cx,cy-dp(3),pen);
        }
    }
}
