package com.s25.dnstile;

import android.Manifest;
import android.content.ComponentName;
import android.content.Context;
import android.content.pm.PackageManager;
import android.provider.Settings;
import android.service.quicksettings.TileService;

import java.util.Locale;
import java.util.regex.Pattern;

/** Changes the SYSTEM Private DNS setting (no VPN, no root). */
public final class DnsControl {
    public static final String KEY_MODE = "private_dns_mode";
    public static final String KEY_HOST = "private_dns_specifier";
    private static final String MODE_OFF = "off";
    private static final String MODE_AUTO = "opportunistic";
    private static final String MODE_HOST = "hostname";
    private static final Pattern DOMAIN = Pattern.compile(
            "(?=.{1,253}$)([a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\\.)+[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?",
            Pattern.CASE_INSENSITIVE);

    private DnsControl() { }

    public static boolean hasPermission(Context c) {
        return c.checkSelfPermission(Manifest.permission.WRITE_SECURE_SETTINGS)
                == PackageManager.PERMISSION_GRANTED;
    }

    public static String currentMode(Context c) {
        String mode = Settings.Global.getString(c.getContentResolver(), KEY_MODE);
        return mode == null || mode.isEmpty() ? MODE_AUTO : mode;
    }

    /** The tile is active only for a manually selected Private DNS hostname.
     * Android Automatic (opportunistic) is the inactive/default state.
     */
    public static boolean enabled(Context c) {
        return MODE_HOST.equals(currentMode(c));
    }

    public static String status(Context c) {
        String mode = currentMode(c);
        if (MODE_OFF.equals(mode)) return "Выключен";
        if (MODE_AUTO.equals(mode)) return "Автоматический";
        if (MODE_HOST.equals(mode)) {
            String h = Settings.Global.getString(c.getContentResolver(), KEY_HOST);
            return h == null || h.isEmpty() ? "DNS выбран, hostname не задан" : h;
        }
        return "Системный режим: " + mode;
    }

    public static String validateHost(String hostname) {
        String s = hostname == null ? "" : hostname.trim().toLowerCase(Locale.ROOT);
        if (s.isEmpty() || !DOMAIN.matcher(s).matches()) {
            throw new IllegalArgumentException("Укажите адрес вида dns.google — без https:// и без IP");
        }
        return s;
    }

    /** Turn the custom DNS toggle off by restoring Android's Automatic mode.
     * Never use MODE_OFF here: that disables Private DNS entirely.
     */
    public static void setAutomatic(Context c) {
        requirePermission(c);
        checkWrite(Settings.Global.putString(c.getContentResolver(), KEY_MODE, MODE_AUTO));
        notifyTile(c);
    }

    public static void setSelectedOn(Context c) {
        requirePermission(c);
        DnsPrefs.Entry selected = DnsPrefs.selected(c);
        if (selected == null) throw new IllegalStateException("Добавьте DNS-сервер");
        // Set provider first, then switch to strict Private DNS mode.
        String host = validateHost(selected.host);
        checkWrite(Settings.Global.putString(c.getContentResolver(), KEY_HOST, host));
        checkWrite(Settings.Global.putString(c.getContentResolver(), KEY_MODE, MODE_HOST));
        notifyTile(c);
    }

    private static void requirePermission(Context c) {
        if (!hasPermission(c)) {
            throw new SecurityException("Сначала выдайте разрешение через Shizuku");
        }
    }

    private static void checkWrite(boolean ok) {
        if (!ok) throw new IllegalStateException("Android не разрешил изменить системный DNS");
    }

    public static void notifyTile(Context c) {
        try {
            TileService.requestListeningState(c, new ComponentName(c, DnsTileService.class));
        } catch (Exception ignored) {
            // The tile may not have been added yet.
        }
    }
}
