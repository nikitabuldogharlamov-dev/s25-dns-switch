package com.s25.dnstile;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.StatusBarManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ComponentName;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

/** Dark, editable DNS list. Tiles always toggle custom hostname <-> Automatic. */
public final class MainActivity extends Activity {
    private static final int BG = Color.rgb(11, 14, 23);
    private static final int PANEL = Color.rgb(23, 29, 43);
    private static final int PANEL_ALT = Color.rgb(29, 36, 53);
    private static final int STROKE = Color.rgb(45, 54, 73);
    private static final int FOREGROUND = Color.rgb(243, 246, 255);
    private static final int MUTED = Color.rgb(157, 169, 192);
    private static final int ACCENT = Color.rgb(138, 149, 255);
    private static final int GREEN = Color.rgb(94, 220, 173);
    private static final String ADB =
            "adb shell pm grant com.s25.dnstile android.permission.WRITE_SECURE_SETTINGS";

    private LinearLayout content;
    private LinearLayout servers;
    private LinearLayout grantCard;
    private TextView statusText;
    private TextView statusDetail;
    private TextView shizukuInfo;
    private Button toggle;
    private ShizukuGrant shizukuGrant;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().getDecorView().setSystemUiVisibility(0);
        shizukuGrant = new ShizukuGrant(this, (success, message) -> {
            toast(message);
            refreshState();
        });

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(19), dp(28), dp(19), dp(40));
        scroll.addView(content);
        setContentView(scroll);

        TextView category = text("УПРАВЛЕНИЕ СЕТЬЮ  /  GALAXY S25", 11, ACCENT, true);
        category.setLetterSpacing(0.10f);
        add(category, 0);
        add(text("DNS Switch", 34, FOREGROUND, true), 6);
        add(text("Твои DNS. Одно касание в шторке.", 14, MUTED, false), 5);

        LinearLayout stateCard = card();
        LinearLayout stateHeading = new LinearLayout(this);
        stateHeading.setOrientation(LinearLayout.HORIZONTAL);
        stateHeading.setGravity(Gravity.CENTER_VERTICAL);
        TextView dot = text("●", 16, GREEN, true);
        stateHeading.addView(dot);
        TextView title = text("  ТЕКУЩИЙ РЕЖИМ", 12, MUTED, true);
        stateHeading.addView(title);
        addTo(stateCard, stateHeading, 0);
        statusText = text("…", 23, FOREGROUND, true);
        addTo(stateCard, statusText, 13);
        statusDetail = text("", 13, MUTED, false);
        addTo(stateCard, statusDetail, 5);
        toggle = button("Включить DNS", true);
        toggle.setOnClickListener(v -> toggleDns());
        addTo(stateCard, toggle, 18);
        add(stateCard, 22);

        grantCard = card();
        addTo(grantCard, text("ОДИН РАЗ  ·  SHIZUKU", 12, ACCENT, true), 0);
        addTo(grantCard, text("Чтобы кнопка в шторке меняла системный DNS, выдайте разрешение через запущенный Shizuku.",
                13, FOREGROUND, false), 11);
        shizukuInfo = text("Проверяем Shizuku…", 12, MUTED, false);
        addTo(grantCard, shizukuInfo, 9);
        Button permission = button("Разрешить через Shizuku", true);
        permission.setOnClickListener(v -> shizukuGrant.start());
        addTo(grantCard, permission, 11);
        Button copy = button("Копировать ADB-команду", false);
        copy.setOnClickListener(v -> {
            ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            if (cm != null) {
                cm.setPrimaryClip(ClipData.newPlainText("ADB", ADB));
                toast("Команда скопирована");
            }
        });
        addTo(grantCard, copy, 10);
        add(grantCard, 15);

        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout labels = new LinearLayout(this);
        labels.setOrientation(LinearLayout.VERTICAL);
        labels.addView(text("МОИ DNS-СЕРВЕРЫ", 12, ACCENT, true));
        labels.addView(text("Выбери, добавь или измени адрес", 12, MUTED, false));
        row.addView(labels, new LinearLayout.LayoutParams(0, -2, 1f));
        Button addServer = smallButton("＋ Добавить");
        addServer.setOnClickListener(v -> editServer(null));
        row.addView(addServer);
        add(row, 27);

        servers = new LinearLayout(this);
        servers.setOrientation(LinearLayout.VERTICAL);
        servers.setBackground(background(PANEL, 21, STROKE));
        servers.setPadding(dp(12), dp(7), dp(12), dp(7));
        add(servers, 12);

        LinearLayout auto = card();
        addTo(auto, text("⚪  ВЫКЛ = АВТОМАТИЧЕСКИ", 13, FOREGROUND, true), 0);
        addTo(auto, text("При выключении плитки Android всегда возвращается в режим «Автоматически». Частный DNS полностью не отключаем.",
                13, MUTED, false), 10);
        add(auto, 18);

        LinearLayout quick = card();
        addTo(quick, text("КНОПКА В ШТОРКЕ", 12, ACCENT, true), 0);
        addTo(quick, text("ВКЛ — выбранный сервер. ВЫКЛ — автоматический DNS.",
                13, MUTED, false), 9);
        Button tile = button("Добавить кнопку в шторку", false);
        tile.setOnClickListener(v -> addTile());
        addTo(quick, tile, 12);
        add(quick, 17);

        add(text("Private DNS использует системный DNS-over-TLS. Адрес вводится без https://. VPN и root не требуются.",
                12, MUTED, false), 18);

        refreshServers();
        refreshState();
    }

    @Override protected void onResume() {
        super.onResume();
        if (statusText != null) refreshState();
    }

    @Override protected void onDestroy() {
        if (shizukuGrant != null) shizukuGrant.release();
        super.onDestroy();
    }

    private void refreshServers() {
        if (servers == null) return;
        servers.removeAllViews();
        List<DnsPrefs.Entry> rows = DnsPrefs.entries(this);
        DnsPrefs.Entry chosen = DnsPrefs.selected(this);
        if (rows.isEmpty()) {
            TextView msg = text("Список пуст. Нажми «Добавить», чтобы создать DNS-сервер.",
                    14, MUTED, false);
            msg.setPadding(dp(8), dp(17), dp(8), dp(17));
            servers.addView(msg);
        }
        for (int i = 0; i < rows.size(); i++) {
            DnsPrefs.Entry item = rows.get(i);
            boolean selected = chosen != null && item.id.equals(chosen.id);
            LinearLayout line = new LinearLayout(this);
            line.setGravity(Gravity.CENTER_VERTICAL);
            line.setOrientation(LinearLayout.HORIZONTAL);
            line.setPadding(dp(4), dp(11), dp(2), dp(11));

            RadioButton radio = new RadioButton(this);
            radio.setButtonTintList(ColorStateList.valueOf(ACCENT));
            radio.setChecked(selected);
            radio.setFocusable(false);
            radio.setClickable(false);
            line.addView(radio, new LinearLayout.LayoutParams(dp(44), dp(47)));

            LinearLayout details = new LinearLayout(this);
            details.setOrientation(LinearLayout.VERTICAL);
            details.setGravity(Gravity.CENTER_VERTICAL);
            TextView name = text(item.label, 15, FOREGROUND, true);
            name.setSingleLine(true);
            name.setEllipsize(android.text.TextUtils.TruncateAt.END);
            details.addView(name);
            TextView host = text(item.host, 12, MUTED, false);
            host.setSingleLine(true);
            host.setEllipsize(android.text.TextUtils.TruncateAt.END);
            details.addView(host);
            line.addView(details, new LinearLayout.LayoutParams(0, -2, 1f));
            details.setOnClickListener(v -> selectServer(item));
            radio.setOnClickListener(v -> selectServer(item));
            line.setOnClickListener(v -> selectServer(item));

            TextView edit = text("✎", 23, ACCENT, false);
            edit.setGravity(Gravity.CENTER);
            edit.setContentDescription("Редактировать " + item.label);
            edit.setBackground(background(PANEL_ALT, 12, 0));
            edit.setOnClickListener(v -> editServer(item));
            LinearLayout.LayoutParams editLayout = new LinearLayout.LayoutParams(dp(43), dp(43));
            editLayout.leftMargin = dp(7);
            line.addView(edit, editLayout);
            servers.addView(line);

            if (i < rows.size() - 1) {
                View sep = new View(this);
                sep.setBackgroundColor(STROKE);
                LinearLayout.LayoutParams sepLp = new LinearLayout.LayoutParams(-1, dp(1));
                sepLp.leftMargin = dp(49);
                servers.addView(sep, sepLp);
            }
        }
    }

    private void selectServer(DnsPrefs.Entry entry) {
        String old = DnsPrefs.selection(this);
        try {
            DnsPrefs.save(this, entry.id);
            if (DnsControl.hasPermission(this) && DnsControl.enabled(this))
                DnsControl.setSelectedOn(this);
            toast("Выбран: " + entry.label);
        } catch (Exception ex) {
            try { DnsPrefs.save(this, old); } catch (Exception ignored) { }
            toast("Не удалось переключить: " + ex.getMessage());
        }
        refreshServers();
        refreshState();
    }

    private void editServer(DnsPrefs.Entry existing) {
        boolean isNew = existing == null;
        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(dp(22), dp(6), dp(22), dp(3));

        form.addView(text("Название (необязательно)", 12, MUTED, false));
        EditText label = input(isNew ? "Например, Домашний DNS" : existing.label,
                isNew ? "" : existing.label);
        form.addView(label);
        form.addView(text("DNS-over-TLS адрес", 12, MUTED, false));
        EditText host = input("например, dns.comss.one", isNew ? "" : existing.host);
        host.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        form.addView(host);
        TextView help = text("Только доменное имя, без https://, порта и IP-адреса.",
                12, MUTED, false);
        help.setPadding(0, dp(8), 0, 0);
        form.addView(help);

        AlertDialog.Builder builder = new AlertDialog.Builder(this)
                .setTitle(isNew ? "Добавить DNS" : "Редактировать DNS")
                .setView(form)
                .setPositiveButton("Сохранить", null)
                .setNegativeButton("Отмена", (dialog, which) -> { });
        if (!isNew) builder.setNeutralButton("Удалить", (dialog, which) -> confirmDelete(existing));
        AlertDialog dialog = builder.create();
        dialog.setOnShowListener(v -> {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(ACCENT);
            dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(MUTED);
            if (!isNew) dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setTextColor(Color.rgb(255, 139, 151));
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v2 -> {
                try {
                    String raw = host.getText().toString().trim();
                    String canonical = DnsControl.validateHost(raw);
                    String name = label.getText().toString().trim();
                    if (name.isEmpty()) name = canonical;
                    if (name.length() > 45) {
                        label.setError("Максимум 45 символов");
                        return;
                    }
                    DnsPrefs.Entry saved = DnsPrefs.upsert(this,
                            isNew ? null : existing.id, name, canonical);
                    if (isNew) {
                        DnsPrefs.save(this, saved.id);
                    }
                    if (DnsControl.hasPermission(this) && DnsControl.enabled(this)) {
                        DnsPrefs.Entry selected = DnsPrefs.selected(this);
                        if (selected != null && selected.id.equals(saved.id))
                            DnsControl.setSelectedOn(this);
                    }
                    dialog.dismiss();
                    toast(isNew ? "DNS добавлен" : "DNS изменён");
                    refreshServers();
                    refreshState();
                } catch (IllegalArgumentException error) {
                    host.setError(error.getMessage());
                } catch (Exception error) {
                    toast("Не удалось применить: " + error.getMessage());
                    refreshServers();
                    refreshState();
                }
            });
        });
        dialog.show();
    }

    private void confirmDelete(DnsPrefs.Entry entry) {
        new AlertDialog.Builder(this)
                .setTitle("Удалить DNS?")
                .setMessage(entry.label + "\n" + entry.host)
                .setNegativeButton("Отмена", null)
                .setPositiveButton("Удалить", (dialog, which) -> {
                    try {
                        DnsPrefs.Entry selected = DnsPrefs.selected(this);
                        if (selected != null && selected.id.equals(entry.id) &&
                                DnsControl.hasPermission(this) && DnsControl.enabled(this)) {
                            DnsControl.setAutomatic(this);
                        }
                        DnsPrefs.delete(this, entry.id);
                        toast("Сервер удалён");
                        refreshServers();
                        refreshState();
                    } catch (Exception err) {
                        toast("Ошибка: " + err.getMessage());
                    }
                }).show();
    }

    private void toggleDns() {
        if (!DnsControl.hasPermission(this)) {
            toast("Сначала разреши управление DNS через Shizuku");
            return;
        }
        try {
            if (DnsControl.enabled(this)) DnsControl.setAutomatic(this);
            else if (DnsPrefs.selected(this) == null) toast("Добавь DNS-сервер");
            else DnsControl.setSelectedOn(this);
        } catch (Exception err) {
            toast("Ошибка: " + err.getMessage());
        }
        refreshState();
    }

    private void refreshState() {
        boolean allowed = DnsControl.hasPermission(this);
        boolean isCustom = DnsControl.enabled(this);
        DnsPrefs.Entry selected = DnsPrefs.selected(this);
        statusText.setText(isCustom ? "Свой DNS включён" : "Автоматический DNS");
        statusDetail.setText(isCustom ? "Активен: " + DnsControl.status(this) :
                "При включении: " + (selected == null ? "добавь сервер" : selected.host));
        toggle.setText(isCustom ? "Вернуть автоматический" : "Включить выбранный DNS");
        toggle.setEnabled(allowed && (isCustom || selected != null));
        toggle.setAlpha(toggle.isEnabled() ? 1f : 0.45f);
        grantCard.setVisibility(allowed ? View.GONE : View.VISIBLE);
        if (!allowed && shizukuInfo != null) {
            try {
                shizukuInfo.setText(rikka.shizuku.Shizuku.pingBinder() ?
                        "Shizuku запущен ✓" : "Сначала запусти Shizuku");
            } catch (Throwable t) {
                shizukuInfo.setText("Не удалось проверить Shizuku");
            }
        }
        DnsControl.notifyTile(this);
    }

    private void addTile() {
        if (Build.VERSION.SDK_INT >= 33) {
            try {
                StatusBarManager manager = getSystemService(StatusBarManager.class);
                if (manager != null) {
                    manager.requestAddTileService(new ComponentName(this, DnsTileService.class),
                            "Частный DNS", Icon.createWithResource(this, R.drawable.ic_dns_tile),
                            getMainExecutor(), result -> {
                                if (result == StatusBarManager.TILE_ADD_REQUEST_RESULT_TILE_ADDED)
                                    toast("Кнопка добавлена");
                                else toast("Добавь «Частный DNS» через карандаш в шторке");
                            });
                    return;
                }
            } catch (Exception ignored) { }
        }
        toast("Открой шторку → Изменить → добавь «Частный DNS»");
    }

    private EditText input(String hint, String value) {
        EditText edit = new EditText(this);
        edit.setHint(hint);
        edit.setText(value);
        edit.setTextColor(FOREGROUND);
        edit.setHintTextColor(MUTED);
        edit.setTextSize(15);
        edit.setSingleLine(true);
        edit.setSelectAllOnFocus(true);
        edit.setPadding(0, dp(7), 0, dp(15));
        return edit;
    }

    private GradientDrawable background(int color, int radiusDp, int strokeColor) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radiusDp));
        if (strokeColor != 0) d.setStroke(dp(1), strokeColor);
        return d;
    }

    private LinearLayout card() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(18), dp(19), dp(18), dp(19));
        layout.setBackground(background(PANEL, 21, STROKE));
        return layout;
    }

    private TextView text(String string, int fontSize, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(string);
        v.setTextSize(fontSize);
        v.setTextColor(color);
        v.setLineSpacing(dp(2), 1f);
        if (bold) v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return v;
    }

    private Button button(String name, boolean primary) {
        Button b = new Button(this);
        b.setText(name);
        b.setAllCaps(false);
        b.setTextColor(primary ? BG : FOREGROUND);
        b.setTextSize(14);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setBackground(background(primary ? ACCENT : PANEL_ALT, 14, primary ? 0 : STROKE));
        b.setMinHeight(dp(51));
        b.setPadding(dp(12), 0, dp(12), 0);
        return b;
    }

    private Button smallButton(String title) {
        Button b = button(title, false);
        b.setTextColor(ACCENT);
        b.setTextSize(12);
        b.setMinHeight(dp(43));
        b.setPadding(dp(11), 0, dp(11), 0);
        return b;
    }

    private void add(View view, int top) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(top);
        content.addView(view, lp);
    }

    private void addTo(LinearLayout parent, View view, int top) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(top);
        parent.addView(view, lp);
    }

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    private int dp(float size) {
        return (int) (size * getResources().getDisplayMetrics().density + 0.5f);
    }
}
