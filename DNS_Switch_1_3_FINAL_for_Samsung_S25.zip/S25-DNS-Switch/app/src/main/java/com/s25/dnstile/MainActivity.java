package com.s25.dnstile;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.StatusBarManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ComponentName;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.SweepGradient;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.Icon;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

/** DNS Switch 1.5. Dark UI; the system tile toggles strict Private DNS and Automatic. */
public final class MainActivity extends Activity {
    private static final int BACK = Color.rgb(8, 13, 23);
    private static final int CARD = Color.rgb(20, 28, 42);
    private static final int CARD2 = Color.rgb(26, 36, 54);
    private static final int OUTLINE = Color.rgb(42, 54, 74);
    private static final int WHITE = Color.rgb(246, 247, 255);
    private static final int SECOND = Color.rgb(147, 160, 183);
    private static final int VIOLET = Color.rgb(120, 74, 246);
    private static final int BLUE = Color.rgb(34, 144, 255);
    private static final int GREEN = Color.rgb(57, 216, 158);
    private static final String ADB = "adb shell pm grant com.s25.dnstile android.permission.WRITE_SECURE_SETTINGS";

    private static final int HOME = 0, DNS = 1, SETTINGS = 2, ABOUT = 3;
    private int tab = HOME;
    private LinearLayout appRoot;
    private LinearLayout mainContent;
    private ShizukuGrant shizukuGrant;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BACK);
        getWindow().setNavigationBarColor(BACK);
        getWindow().getDecorView().setSystemUiVisibility(0);
        shizukuGrant = new ShizukuGrant(this, (success, message) -> {
            toast(message);
            render();
        });
        if (savedInstanceState != null) tab = savedInstanceState.getInt("tab", HOME);
        render();
    }

    @Override protected void onSaveInstanceState(Bundle state) {
        state.putInt("tab", tab);
        super.onSaveInstanceState(state);
    }

    @Override protected void onResume() {
        super.onResume();
        if (appRoot != null) render();
    }

    @Override protected void onDestroy() {
        if (shizukuGrant != null) shizukuGrant.release();
        super.onDestroy();
    }

    @Override public void onBackPressed() {
        if (tab != HOME) { tab = HOME; render(); }
        else super.onBackPressed();
    }

    private void render() {
        appRoot = new LinearLayout(this);
        appRoot.setBackgroundColor(BACK);
        appRoot.setOrientation(LinearLayout.VERTICAL);
        setContentView(appRoot);
        header();
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setVerticalScrollBarEnabled(false);
        mainContent = new LinearLayout(this);
        mainContent.setOrientation(LinearLayout.VERTICAL);
        mainContent.setPadding(dp(20), dp(11), dp(20), dp(29));
        scroll.addView(mainContent);
        appRoot.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        if (tab == HOME) home();
        else if (tab == DNS) dnsList();
        else if (tab == SETTINGS) settingsPage();
        else aboutPage();
        bottomBar();
        DnsControl.notifyTile(this);
    }

    private void header() {
        LinearLayout row = horizontal(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(20), dp(15), dp(20), dp(12));
        TextView logo = logo(42);
        row.addView(logo, new LinearLayout.LayoutParams(dp(42), dp(42)));
        LinearLayout names = vertical();
        TextView name = text("DNS Switch", 22, WHITE, true);
        names.addView(name);
        names.addView(text("Личный менеджер DNS", 11, SECOND, false));
        LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(0, -2, 1);
        np.leftMargin = dp(12);
        row.addView(names, np);
        TextView tool = text(tab == SETTINGS ? "✕" : "⚙", 24, WHITE, false);
        tool.setGravity(Gravity.CENTER);
        tool.setContentDescription(tab == SETTINGS ? "Главная" : "Настройки");
        tool.setBackground(round(CARD, 13, OUTLINE));
        row.addView(tool, new LinearLayout.LayoutParams(dp(44), dp(44)));
        tool.setOnClickListener(v -> navigate(tab == SETTINGS ? HOME : SETTINGS));
        appRoot.addView(row);
    }

    private void home() {
        boolean permitted = DnsControl.hasPermission(this);
        boolean enabled = DnsControl.enabled(this);
        DnsPrefs.Entry current = DnsPrefs.selected(this);
        LinearLayout hero = vertical();
        hero.setGravity(Gravity.CENTER_HORIZONTAL);
        space(hero, 14);
        PowerOrb power = new PowerOrb(enabled);
        power.setContentDescription(enabled ? "Выключить выбранный DNS" : "Включить выбранный DNS");
        hero.addView(power, new LinearLayout.LayoutParams(dp(175), dp(175)));
        power.setOnClickListener(v -> toggle());
        space(hero, 13);
        TextView status = text(enabled ? "Активен" : "Автоматический DNS", 24, WHITE, true);
        status.setGravity(Gravity.CENTER);
        hero.addView(status);
        TextView subtitle = text(enabled ? "Используется выбранный Private DNS" :
                "Android использует системный режим", 13, SECOND, false);
        subtitle.setGravity(Gravity.CENTER);
        addTo(hero, subtitle, 6);
        add(hero, 0);

        LinearLayout selected = panel();
        addTo(selected, text("ТЕКУЩИЙ DNS", 11, SECOND, true), 0);
        LinearLayout picked = horizontal(Gravity.CENTER_VERTICAL);
        TextView icon = text("✦", 27, VIOLET, true);
        icon.setGravity(Gravity.CENTER);
        icon.setBackground(round(CARD2, 14, 0));
        picked.addView(icon, new LinearLayout.LayoutParams(dp(54), dp(54)));
        LinearLayout desc = vertical();
        desc.addView(text(current == null ? "Сервер не выбран" : current.label, 17, WHITE, true));
        TextView host = text(current == null ? "Добавь DNS в список" : current.host, 12, SECOND, false);
        host.setSingleLine(true);
        host.setEllipsize(android.text.TextUtils.TruncateAt.END);
        addTo(desc, host, 5);
        LinearLayout.LayoutParams dp = new LinearLayout.LayoutParams(0, -2, 1);
        dp.leftMargin = dp(12);
        picked.addView(desc, dp);
        picked.addView(text("›", 32, SECOND, false));
        addTo(selected, picked, 13);
        selected.setOnClickListener(v -> navigate(DNS));
        add(selected, 25);

        LinearLayout indicator = panel();
        LinearLayout indicatorRow = horizontal(Gravity.CENTER_VERTICAL);
        TextView shield = text(permitted ? "✓" : "!", 23, permitted ? GREEN : Color.rgb(255, 188, 103), true);
        shield.setGravity(Gravity.CENTER);
        shield.setBackground(round(CARD2, 14, 0));
        indicatorRow.addView(shield, new LinearLayout.LayoutParams(dp(47), dp(47)));
        LinearLayout description = vertical();
        description.addView(text(permitted ? "Управление DNS разрешено" : "Нужно разрешение Shizuku", 14, permitted ? GREEN : WHITE, true));
        addTo(description, text(permitted ? "Системные настройки доступны" : "Нажми, чтобы настроить один раз", 12, SECOND, false), 3);
        LinearLayout.LayoutParams dd = new LinearLayout.LayoutParams(0,-2,1);
        dd.leftMargin = dp(12);
        indicatorRow.addView(description, dd);
        indicator.addView(indicatorRow);
        indicator.setOnClickListener(v -> navigate(SETTINGS));
        add(indicator, 12);

        add(text("БЫСТРОЕ ПЕРЕКЛЮЧЕНИЕ", 13, WHITE, true), 28);
        HorizontalScrollView shortcutScroll = new HorizontalScrollView(this);
        shortcutScroll.setHorizontalScrollBarEnabled(false);
        LinearLayout chips = horizontal(Gravity.CENTER_VERTICAL);
        List<DnsPrefs.Entry> entries = DnsPrefs.entries(this);
        for (DnsPrefs.Entry e : entries) {
            boolean chosen = current != null && current.id.equals(e.id);
            LinearLayout chip = vertical();
            chip.setGravity(Gravity.CENTER);
            chip.setPadding(dp(14), dp(13), dp(14), dp(13));
            chip.setBackground(round(chosen ? Color.rgb(37, 32, 83) : CARD, 17, chosen ? VIOLET : OUTLINE));
            chip.addView(text("✦", 22, chosen ? Color.rgb(181, 148, 255) : BLUE, true));
            TextView t = text(e.label, 11, WHITE, false);
            t.setMaxWidth(dp(110));
            t.setSingleLine(true);
            t.setEllipsize(android.text.TextUtils.TruncateAt.END);
            addTo(chip, t, 8);
            LinearLayout.LayoutParams chipLp = new LinearLayout.LayoutParams(dp(128), dp(88));
            chipLp.rightMargin = dp(10);
            chips.addView(chip, chipLp);
            chip.setOnClickListener(v -> select(e));
        }
        shortcutScroll.addView(chips);
        add(shortcutScroll, 12);
        add(text("ВКЛ — выбранный DNS • ВЫКЛ — Автоматически", 12, SECOND, false), 17);
    }

    private void dnsList() {
        LinearLayout heading = horizontal(Gravity.CENTER_VERTICAL);
        LinearLayout titles = vertical();
        titles.addView(text("Список DNS", 24, WHITE, true));
        addTo(titles, text("Добавляй, выбирай и редактируй", 12, SECOND, false), 5);
        heading.addView(titles, new LinearLayout.LayoutParams(0, -2, 1));
        Button plus = button("＋", true);
        plus.setTextSize(24);
        heading.addView(plus, new LinearLayout.LayoutParams(dp(49), dp(49)));
        plus.setOnClickListener(v -> edit(null));
        add(heading, 6);
        DnsPrefs.Entry chosen = DnsPrefs.selected(this);
        List<DnsPrefs.Entry> entries = DnsPrefs.entries(this);
        if (entries.isEmpty()) add(text("Пока нет серверов. Нажми +, чтобы добавить DNS-over-TLS.", 15, SECOND, false), 24);
        for (DnsPrefs.Entry e : entries) {
            boolean isSelected = chosen != null && e.id.equals(chosen.id);
            LinearLayout card = panel();
            LinearLayout row = horizontal(Gravity.CENTER_VERTICAL);
            TextView badge = text("✦", 24, isSelected ? BLUE : SECOND, true);
            badge.setGravity(Gravity.CENTER);
            badge.setBackground(round(CARD2, 13, OUTLINE));
            row.addView(badge, new LinearLayout.LayoutParams(dp(48), dp(48)));
            LinearLayout details = vertical();
            details.addView(text(e.label, 16, WHITE, true));
            TextView host = text(e.host, 12, SECOND, false);
            host.setSingleLine(true);
            host.setEllipsize(android.text.TextUtils.TruncateAt.END);
            addTo(details, host, 4);
            LinearLayout.LayoutParams detailLp = new LinearLayout.LayoutParams(0,-2,1);
            detailLp.leftMargin = dp(12);
            row.addView(details, detailLp);
            TextView marker = text(isSelected ? "✓" : "○", 22, isSelected ? VIOLET : SECOND, true);
            marker.setGravity(Gravity.CENTER);
            row.addView(marker, new LinearLayout.LayoutParams(dp(33),dp(44)));
            TextView edit = text("⋮", 24, SECOND, true);
            edit.setGravity(Gravity.CENTER);
            edit.setBackground(round(CARD2,12,0));
            edit.setContentDescription("Редактировать " + e.label);
            row.addView(edit, new LinearLayout.LayoutParams(dp(36),dp(44)));
            edit.setOnClickListener(v -> edit(e));
            card.addView(row);
            if (isSelected) addTo(card,text("✓  ВЫБРАННЫЙ СЕРВЕР",11,Color.rgb(173,149,255),true),9);
            row.setOnClickListener(v -> select(e));
            add(card, 10);
        }
        LinearLayout info = panel();
        info.addView(text("Адрес сервера", 14, WHITE, true));
        addTo(info, text("Android Private DNS принимает имя DNS-over-TLS сервера, например dns.google. IP-адреса 1.1.1.1 и 8.8.8.8 сюда не подходят.", 13, SECOND, false), 8);
        add(info, 18);
    }

    private void settingsPage() {
        add(text("Настройки", 24, WHITE, true), 6);
        add(text("СИСТЕМА И РАЗРЕШЕНИЯ", 11, VIOLET, true), 24);
        LinearLayout perms = panel();
        boolean has = DnsControl.hasPermission(this);
        addTo(perms, text(has ? "✓  Разрешение получено" : "◈  Shizuku", 16, WHITE, true), 0);
        addTo(perms,text(has ? "Переключение Private DNS доступно без запущенного Shizuku." :
                "Нужно один раз разрешить WRITE_SECURE_SETTINGS.", 13, SECOND, false), 9);
        if (!has) {
            Button grant = button("Разрешить через Shizuku", true);
            grant.setOnClickListener(v -> shizukuGrant.start());
            addTo(perms, grant, 14);
            Button adb = button("Копировать ADB-команду", false);
            adb.setOnClickListener(v -> {
                ClipboardManager cm = (ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
                if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("ADB", ADB));
                toast("Команда скопирована");
            });
            addTo(perms, adb, 10);
        }
        add(perms, 12);
        LinearLayout tile = panel();
        tile.addView(text("✦  Значок ИИ в шторке", 16, WHITE, true));
        addTo(tile,text("Белые буквы «ИИ» и звёздочка. Активный цвет плитки выбирает One UI.",13,SECOND,false),8);
        Button addTile = button("Добавить в шторку", false);
        addTile.setOnClickListener(v -> addTile());
        addTo(tile, addTile, 13);
        add(tile, 12);
        add(text("РЕЖИМ DNS", 11, VIOLET, true), 25);
        LinearLayout mode = panel();
        mode.addView(text("Системный Private DNS", 15, WHITE, true));
        addTo(mode, text("ВКЛ → выбранный hostname. ВЫКЛ → режим Android «Автоматически». Этот режим влияет на системное разрешение доменных имён, а не только на ИИ-сервисы.",13,SECOND,false),9);
        add(mode, 10);
        LinearLayout future = panel();
        future.addView(text("Только ИИ-сервисы", 15, WHITE, true));
        addTo(future,text("Раздельный DNS по доменам потребует отдельного локального DNS-посредника/VPN. В версии 1.5 эта функция пока не включена.",13,SECOND,false),9);
        add(future, 11);
        Button about = button("О приложении   ›",false);
        about.setOnClickListener(v -> navigate(ABOUT));
        add(about,20);
    }

    private void aboutPage() {
        LinearLayout hero = vertical();
        hero.setGravity(Gravity.CENTER_HORIZONTAL);
        TextView aboutLogo = logo(94);
        LinearLayout.LayoutParams aboutLp = new LinearLayout.LayoutParams(dp(94),dp(94));
        aboutLp.topMargin = dp(50);
        hero.addView(aboutLogo,aboutLp);
        addTo(hero, text("DNS Switch", 28, WHITE, true), 17);
        addTo(hero, text("Версия 1.5 • Samsung One UI", 13, SECOND, false), 7);
        add(hero, 0);
        LinearLayout info = panel();
        info.addView(text("Как это работает",16,WHITE,true));
        addTo(info,text("Приложение изменяет системные параметры Private DNS Android с разрешением WRITE_SECURE_SETTINGS. Shizuku нужен только для выдачи разрешения.",13,SECOND,false),12);
        addTo(info,text("ВКЛ: выбранный сервер DNS-over-TLS. ВЫКЛ: автоматический режим Android.",13,WHITE,false),14);
        add(info, 40);
        Button repo = button("Открыть GitHub проекта",false);
        repo.setOnClickListener(v -> {
            try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://github.com/nikitabuldogharlamov-dev/s25-dns-switch"))); }
            catch (Exception ex) { toast("Не удалось открыть ссылку"); }
        });
        add(repo, 14);
    }

    private void bottomBar() {
        LinearLayout nav = horizontal(Gravity.CENTER_VERTICAL);
        nav.setPadding(dp(12), dp(9), dp(12), dp(13));
        nav.setBackground(round(Color.rgb(12, 18, 29), 20, OUTLINE));
        String[] titles = {"Главная", "DNS", "Настройки"};
        String[] symbols = {"⌂", "☷", "⚙"};
        for (int i = 0; i < 3; i++) {
            final int n = i;
            boolean chosen = tab == i || (tab == ABOUT && i == SETTINGS);
            LinearLayout cell = vertical();
            cell.setGravity(Gravity.CENTER);
            cell.setPadding(0,dp(3),0,dp(3));
            TextView ico = text(symbols[i], 27, chosen ? Color.rgb(188,159,255) : SECOND, true);
            ico.setGravity(Gravity.CENTER);
            cell.addView(ico);
            TextView label = text(titles[i], 11, chosen ? WHITE : SECOND, false);
            addTo(cell,label,3);
            nav.addView(cell,new LinearLayout.LayoutParams(0,dp(55),1));
            cell.setContentDescription(titles[i]);
            cell.setOnClickListener(v -> navigate(n));
        }
        appRoot.addView(nav);
    }

    private void select(DnsPrefs.Entry e) {
        String previous = DnsPrefs.selection(this);
        try {
            DnsPrefs.save(this,e.id);
            if (DnsControl.hasPermission(this) && DnsControl.enabled(this)) DnsControl.setSelectedOn(this);
            toast("Выбран: " + e.label);
        } catch (Exception ex) {
            try { DnsPrefs.save(this, previous); } catch(Exception ignored) { }
            toast("Ошибка: " + ex.getMessage());
        }
        render();
    }

    private void toggle() {
        if (!DnsControl.hasPermission(this)) { navigate(SETTINGS); toast("Нужно разрешение Shizuku"); return; }
        try {
            if (DnsControl.enabled(this)) DnsControl.setAutomatic(this);
            else if (DnsPrefs.selected(this) == null) { navigate(DNS); toast("Сначала добавь сервер"); return; }
            else DnsControl.setSelectedOn(this);
        } catch(Exception ex) { toast("Ошибка: " + ex.getMessage()); }
        render();
    }

    private void edit(DnsPrefs.Entry existing) {
        boolean create = existing == null;
        LinearLayout form = vertical();
        form.setPadding(dp(20),dp(13),dp(20),dp(7));
        form.addView(text("НАЗВАНИЕ",12,SECOND,true));
        EditText label = editText("Мой DNS",create ? "" : existing.label);
        addTo(form,label,5);
        addTo(form,text("АДРЕС DNS-over-TLS",12,SECOND,true),17);
        EditText host = editText("dns.example.com",create ? "" : existing.host);
        host.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        addTo(form,host,5);
        addTo(form,text("Домен без https://, порта и IP-адреса",12,SECOND,false),8);
        AlertDialog.Builder b = new AlertDialog.Builder(this)
                .setTitle(create ? "Добавить DNS" : "Редактировать DNS")
                .setView(form)
                .setPositiveButton("Сохранить",null)
                .setNegativeButton("Отмена",null);
        if (!create) b.setNeutralButton("Удалить",(d,w) -> delete(existing));
        AlertDialog dialog = b.create();
        dialog.setOnShowListener(v -> {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(VIOLET);
            dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(SECOND);
            if (!create) dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setTextColor(Color.rgb(255,140,152));
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v2 -> {
                try {
                    String dns = DnsControl.validateHost(host.getText().toString());
                    DnsPrefs.Entry saved = DnsPrefs.upsert(this,create ? null : existing.id,
                            label.getText().toString(),dns);
                    if (create) DnsPrefs.save(this,saved.id);
                    if (DnsControl.hasPermission(this) && DnsControl.enabled(this)) {
                        DnsPrefs.Entry chosen = DnsPrefs.selected(this);
                        if (chosen != null && chosen.id.equals(saved.id)) DnsControl.setSelectedOn(this);
                    }
                    dialog.dismiss();
                    toast(create ? "DNS добавлен" : "DNS обновлён");
                    render();
                } catch (IllegalArgumentException ex) { host.setError(ex.getMessage()); }
                catch (Exception ex) { toast("DNS сохранён, но не применён: " + ex.getMessage()); render(); }
            });
        });
        dialog.show();
    }

    private void delete(DnsPrefs.Entry e) {
        new AlertDialog.Builder(this).setTitle("Удалить DNS?")
                .setMessage(e.label + "\n" + e.host)
                .setNegativeButton("Отмена",null)
                .setPositiveButton("Удалить",(d,w) -> {
                    try {
                        DnsPrefs.Entry chosen = DnsPrefs.selected(this);
                        if (chosen != null && chosen.id.equals(e.id) && DnsControl.hasPermission(this) && DnsControl.enabled(this)) DnsControl.setAutomatic(this);
                        DnsPrefs.delete(this,e.id);
                        toast("DNS удалён");
                        render();
                    } catch(Exception ex) { toast("Ошибка: " + ex.getMessage()); }
                }).show();
    }

    private void addTile() {
        if (Build.VERSION.SDK_INT >= 33) {
            try {
                StatusBarManager s = getSystemService(StatusBarManager.class);
                if (s != null) {
                    s.requestAddTileService(new ComponentName(this,DnsTileService.class),
                            "DNS • ИИ",Icon.createWithResource(this,R.drawable.ic_dns_tile),
                            getMainExecutor(), result -> toast(result == StatusBarManager.TILE_ADD_REQUEST_RESULT_TILE_ADDED ?
                                    "Добавлено в шторку" : "Открой шторку → Изменить → DNS • ИИ"));
                    return;
                }
            } catch(Exception ignored) { }
        }
        toast("Открой шторку → Изменить → DNS • ИИ");
    }

    private void navigate(int page) { tab = page; render(); }
    private void toast(String value) { Toast.makeText(this,value,Toast.LENGTH_SHORT).show(); }

    private LinearLayout horizontal(int alignment) { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); l.setGravity(alignment); return l; }
    private LinearLayout vertical() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    private GradientDrawable round(int color, int radius, int border) {
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(color); gd.setCornerRadius(dp(radius));
        if (border != 0) gd.setStroke(dp(1), border);
        return gd;
    }
    private LinearLayout panel() {
        LinearLayout box = vertical();
        box.setPadding(dp(17),dp(17),dp(17),dp(17));
        box.setBackground(round(CARD, 19, OUTLINE));
        return box;
    }
    private TextView text(String title, int size, int color, boolean heavy) {
        TextView t = new TextView(this);
        t.setText(title); t.setTextSize(size); t.setTextColor(color);
        t.setLineSpacing(dp(2),1.02f);
        if (heavy) t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        return t;
    }
    private TextView logo(int dimension) {
        TextView mark = text("ИИ✦", dimension >= 90 ? 26 : 15, WHITE, true);
        mark.setGravity(Gravity.CENTER);
        GradientDrawable gradient = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[] { BLUE, VIOLET, Color.rgb(207,53,212) });
        gradient.setCornerRadius(dp(dimension / 4f));
        mark.setBackground(gradient);
        mark.setContentDescription("Логотип ИИ и звёздочка");
        // Width/height are configured by parent LayoutParams, but About page needs explicit bounds.
        if (dimension >= 90) mark.setLayoutParams(new LinearLayout.LayoutParams(dp(dimension),dp(dimension)));
        return mark;
    }
    private Button button(String title, boolean primary) {
        Button b = new Button(this);
        b.setText(title); b.setAllCaps(false);
        b.setTextColor(WHITE); b.setTextSize(14); b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        b.setBackground(round(primary ? VIOLET : CARD2,14,primary ? 0 : OUTLINE));
        b.setMinHeight(dp(48));
        return b;
    }
    private EditText editText(String hint,String value) {
        EditText e = new EditText(this);
        e.setHint(hint); e.setText(value); e.setSingleLine(true); e.setSelectAllOnFocus(true);
        e.setTextColor(WHITE); e.setHintTextColor(SECOND); e.setTextSize(15);
        e.setPadding(0,dp(8),0,dp(10));
        return e;
    }
    private void add(View view, int marginTop) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1,-2);
        lp.topMargin = dp(marginTop);
        mainContent.addView(view,lp);
    }
    private void addTo(LinearLayout parent, View view, int marginTop) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1,-2);
        lp.topMargin = dp(marginTop);
        parent.addView(view,lp);
    }
    private void space(LinearLayout parent,int height) { View v=new View(this); parent.addView(v,new LinearLayout.LayoutParams(1,dp(height))); }
    private int dp(float n) { return (int)(n*getResources().getDisplayMetrics().density + 0.5f); }

    /** Draws the glowing two-tone power switch without bitmap assets or network dependencies. */
    private final class PowerOrb extends View {
        private final boolean on;
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        PowerOrb(boolean active) { super(MainActivity.this); on = active; setLayerType(View.LAYER_TYPE_SOFTWARE,null); }
        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float width = getWidth(), height = getHeight();
            float cx = width/2f, cy = height/2f, radius=Math.min(width,height)*.40f;
            paint.setStyle(Paint.Style.STROKE); paint.setStrokeCap(Paint.Cap.ROUND);
            paint.setStrokeWidth(dp(8));
            paint.setShader(new SweepGradient(cx,cy,new int[]{BLUE,VIOLET,BLUE},null));
            paint.setShadowLayer(on ? dp(17) : dp(6),0,0,on ? VIOLET : OUTLINE);
            canvas.drawCircle(cx,cy,radius,paint);
            paint.clearShadowLayer(); paint.setShader(null);
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(CARD);
            canvas.drawCircle(cx,cy,radius-dp(6),paint);
            paint.setColor(on ? WHITE : SECOND);
            paint.setStyle(Paint.Style.STROKE); paint.setStrokeCap(Paint.Cap.ROUND);
            paint.setStrokeWidth(dp(6));
            RectF arc = new RectF(cx-dp(20),cy-dp(20),cx+dp(20),cy+dp(20));
            canvas.drawArc(arc,-52,284,false,paint);
            canvas.drawLine(cx,cy-dp(27),cx,cy-dp(2),paint);
        }
    }
}
