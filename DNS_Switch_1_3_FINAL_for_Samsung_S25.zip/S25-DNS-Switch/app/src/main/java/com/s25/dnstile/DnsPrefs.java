package com.s25.dnstile;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/** Editable DNS-over-TLS providers. Old v1.3 selections are migrated unchanged. */
public final class DnsPrefs {
    public static final String AUTO = "auto";
    private static final String PREF = "dns_settings";
    private static final String KEY_ENTRIES = "dns_entries_v2";
    private static final String KEY_SELECTED = "selected";

    public static final class Entry {
        public final String id;
        public final String label;
        public final String host;
        public Entry(String id, String label, String host) {
            this.id = id;
            this.label = label;
            this.host = host;
        }
    }

    private DnsPrefs() { }

    private static SharedPreferences prefs(Context ctx) {
        return ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE);
    }

    /** Only runs at first startup of v1.4. Never re-seeds deleted providers. */
    private static void ensureMigrated(Context c) {
        SharedPreferences sp = prefs(c);
        if (sp.contains(KEY_ENTRIES)) return;
        JSONArray defaults = new JSONArray();
        String[][] seeds = {
            {"comss_one", "dns.comss.one", "dns.comss.one"},
            {"comss_control", "comss.dns.controld.com", "comss.dns.controld.com"},
            {"geohide", "dns.geohide.ru", "dns.geohide.ru"},
            {"xbox", "xbox-dns.ru", "xbox-dns.ru"},
            {"dns_ai", "dns.dns-ai.ru", "dns.dns-ai.ru"},
            {"webshift", "d.webshiftvpn.ru", "d.webshiftvpn.ru"}
        };
        for (String[] seed : seeds) defaults.put(toJson(new Entry(seed[0], seed[1], seed[2])));
        String prior = sp.getString(KEY_SELECTED, AUTO);
        if (AUTO.equals(prior)) prior = seeds[0][0];
        sp.edit().putString(KEY_ENTRIES, defaults.toString())
                .putString(KEY_SELECTED, prior).commit();
    }

    private static JSONObject toJson(Entry e) {
        JSONObject json = new JSONObject();
        try {
            json.put("id", e.id);
            json.put("label", e.label);
            json.put("host", e.host);
        } catch (JSONException ignored) { }
        return json;
    }

    public static synchronized List<Entry> entries(Context c) {
        ensureMigrated(c);
        List<Entry> results = new ArrayList<>();
        try {
            JSONArray items = new JSONArray(prefs(c).getString(KEY_ENTRIES, "[]"));
            for (int i = 0; i < items.length(); i++) {
                JSONObject item = items.optJSONObject(i);
                if (item == null) continue;
                String id = item.optString("id", "");
                String host = item.optString("host", "");
                String label = item.optString("label", "");
                if (!id.isEmpty() && !host.isEmpty()) results.add(
                        new Entry(id, label.isEmpty() ? host : label, host));
            }
        } catch (JSONException ignored) { }
        return results;
    }

    private static void write(Context c, List<Entry> rows) {
        JSONArray items = new JSONArray();
        for (Entry e : rows) items.put(toJson(e));
        prefs(c).edit().putString(KEY_ENTRIES, items.toString()).commit();
    }

    public static synchronized Entry selected(Context c) {
        List<Entry> rows = entries(c);
        String id = prefs(c).getString(KEY_SELECTED, "");
        for (Entry e : rows) if (e.id.equals(id)) return e;
        return rows.isEmpty() ? null : rows.get(0);
    }

    public static synchronized String selection(Context c) {
        Entry e = selected(c);
        return e == null ? AUTO : e.id;
    }

    public static synchronized void save(Context c, String id) {
        for (Entry e : entries(c)) {
            if (e.id.equals(id)) {
                prefs(c).edit().putString(KEY_SELECTED, id).commit();
                return;
            }
        }
        throw new IllegalArgumentException("Сервер не найден");
    }

    public static synchronized Entry upsert(Context c, String id, String label, String hostname) {
        String host = DnsControl.validateHost(hostname);
        String name = label == null ? "" : label.trim();
        if (name.isEmpty()) name = host;
        if (name.length() > 45) throw new IllegalArgumentException("Имя не должно превышать 45 символов");
        String key = id == null ? UUID.randomUUID().toString() : id;
        List<Entry> rows = entries(c);
        Entry item = new Entry(key, name, host);
        boolean replaced = false;
        for (int i = 0; i < rows.size(); i++) {
            if (rows.get(i).id.equals(key)) {
                rows.set(i, item);
                replaced = true;
                break;
            }
        }
        if (!replaced) rows.add(item);
        write(c, rows);
        if (selected(c) == null) prefs(c).edit().putString(KEY_SELECTED, key).commit();
        return item;
    }

    public static synchronized void delete(Context c, String id) {
        List<Entry> rows = entries(c);
        boolean found = false;
        for (int i = rows.size()-1; i >= 0; i--) {
            if (rows.get(i).id.equals(id)) {
                rows.remove(i);
                found = true;
            }
        }
        if (!found) return;
        write(c, rows);
        if (id.equals(prefs(c).getString(KEY_SELECTED, ""))) {
            prefs(c).edit().putString(KEY_SELECTED, rows.isEmpty() ? AUTO : rows.get(0).id).commit();
        }
    }

    public static String host(Context c) {
        Entry e = selected(c);
        return e == null ? "" : e.host;
    }

    public static String name(Context c) {
        Entry e = selected(c);
        return e == null ? "Добавьте сервер" : e.label;
    }
}
