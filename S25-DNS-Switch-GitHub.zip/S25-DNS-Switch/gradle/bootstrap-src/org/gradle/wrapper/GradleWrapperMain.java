package org.gradle.wrapper;

import java.io.*;
import java.net.URI;
import java.nio.file.*;
import java.util.*;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/** Minimal, inspectable first-run Gradle bootstrap for this standalone example.
 * Downloads the Gradle distribution in gradle-wrapper.properties, then invokes it.
 * This is NOT the official Gradle Wrapper binary. */
public final class GradleWrapperMain {
    public static void main(String[] args) throws Exception {
        Path root = Paths.get(System.getProperty("user.dir")).toAbsolutePath().normalize();
        Properties props = new Properties();
        try (InputStream in = Files.newInputStream(root.resolve("gradle/wrapper/gradle-wrapper.properties"))) {
            props.load(in);
        }
        String url = props.getProperty("distributionUrl");
        if (url == null || !url.startsWith("https://services.gradle.org/distributions/gradle-")) {
            throw new IOException("Unexpected Gradle distribution URL: " + url);
        }
        String archiveName = url.substring(url.lastIndexOf('/') + 1);
        if (!archiveName.matches("gradle-[0-9.]+-bin\\.zip")) throw new IOException("Unexpected archive name");
        String dirName = archiveName.replace("-bin.zip", "");
        Path cache = root.resolve(".gradle/bootstrap");
        Path gradleHome = cache.resolve(dirName);
        Path executable = gradleHome.resolve("bin/").resolve(isWindows() ? "gradle.bat" : "gradle");
        if (!Files.isRegularFile(executable)) {
            Files.createDirectories(cache);
            Path zip = cache.resolve(archiveName);
            if (!Files.exists(zip)) {
                System.out.println("Downloading " + url + " (first build only)...");
                Path partial = cache.resolve(archiveName + ".partial");
                try (InputStream input = URI.create(url).toURL().openStream()) {
                    Files.copy(input, partial, StandardCopyOption.REPLACE_EXISTING);
                }
                Files.move(partial, zip, StandardCopyOption.REPLACE_EXISTING);
            }
            System.out.println("Extracting Gradle...");
            try (ZipInputStream in = new ZipInputStream(Files.newInputStream(zip))) {
                ZipEntry entry;
                while ((entry = in.getNextEntry()) != null) {
                    Path output = cache.resolve(entry.getName()).normalize();
                    if (!output.startsWith(cache)) throw new IOException("Unsafe ZIP entry");
                    if (entry.isDirectory()) Files.createDirectories(output);
                    else {
                        Files.createDirectories(output.getParent());
                        Files.copy(in, output, StandardCopyOption.REPLACE_EXISTING);
                    }
                    in.closeEntry();
                }
            }
            if (!isWindows()) executable.toFile().setExecutable(true);
        }
        List<String> command = new ArrayList<>();
        if (isWindows()) {
            command.add("cmd"); command.add("/c");
        }
        command.add(executable.toString());
        Collections.addAll(command, args);
        ProcessBuilder pb = new ProcessBuilder(command).directory(root.toFile()).inheritIO();
        int code = pb.start().waitFor();
        System.exit(code);
    }
    private static boolean isWindows() {
        return System.getProperty("os.name").toLowerCase(Locale.ROOT).contains("win");
    }
}
