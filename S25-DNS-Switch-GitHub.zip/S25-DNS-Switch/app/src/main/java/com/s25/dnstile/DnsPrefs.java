package com.s25.dnstile;

import android.content.Context;
import android.content.SharedPreferences;

/** Preferred DNS to restore when the Quick Settings tile switches from OFF to ON. */
public final class DnsPrefs {
    public static final String AUTO = "auto";
    public static final String CF = "cloudflare";
    public static final String GOOGLE = "google";
    public static final String QUAD9 = "quad9";
    public static final String ADGUARD = "adguard";
    public static final String MULLVAD = "mullvad";
    public static final String CUSTOM = "custom";

    public static final String[][] OPTIONS = {
            {AUTO, "Автоматический", "DNS от сети · с попыткой шифрования"},
            {CF, "Cloudflare", "one.one.one.one"},
            {GOOGLE, "Google", "dns.google"},
            {QUAD9, "Quad9", "dns.quad9.net"},
            {ADGUARD, "AdGuard", "dns.adguard-dns.com"},
            {MULLVAD, "Mullvad", "dns.mullvad.net"},
            {CUSTOM, "Свой DNS", "Введите hostname DNS-over-TLS"}
    };

    private DnsPrefs() { }

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences("dns_settings", Context.MODE_PRIVATE);
    }

    public static String selection(Context c) {
        String s = prefs(c).getString("selected", AUTO);
        for (String[] option : OPTIONS) {
            if (option[0].equals(s)) return s;
        }
        return AUTO;
    }

    public static String customHost(Context c) {
        return prefs(c).getString("custom_host", "");
    }

    public static void save(Context c, String selection, String custom) {
        prefs(c).edit().putString("selected", selection)
                .putString("custom_host", custom).apply();
    }

    public static String host(Context c) {
        String selected = selection(c);
        if (CUSTOM.equals(selected)) return customHost(c);
        for (String[] option : OPTIONS) {
            if (option[0].equals(selected)) {
                return AUTO.equals(selected) ? "" : option[2];
            }
        }
        return "";
    }

    public static String name(Context c) {
        String selected = selection(c);
        for (String[] option : OPTIONS) {
            if (option[0].equals(selected)) return option[1];
        }
        return "Автоматический";
    }
}
