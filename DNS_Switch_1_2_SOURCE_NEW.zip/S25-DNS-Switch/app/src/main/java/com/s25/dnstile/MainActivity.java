package com.s25.dnstile;

import android.app.Activity;
import android.app.StatusBarManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ComponentName;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

/** Samsung-friendly configuration screen. No VPN and no background service. */
public final class MainActivity extends Activity {
    private static final int BG = Color.rgb(246, 248, 253);
    private static final int DARK = Color.rgb(26, 38, 63);
    private static final int MUTED = Color.rgb(111, 124, 147);
    private static final int BLUE = Color.rgb(60, 97, 234);
    private static final int WHITE = Color.WHITE;
    private static final String ADB_COMMAND =
            "adb shell pm grant com.s25.dnstile android.permission.WRITE_SECURE_SETTINGS";

    private LinearLayout container;
    private TextView currentStatus;
    private TextView currentDesc;
    private Button toggleButton;
    private LinearLayout setupCard;
    private ShizukuGrant shizukuGrant;
    private TextView shizukuInfo;
    private Button shizukuButton;
    private final RadioButton[] radios = new RadioButton[DnsPrefs.OPTIONS.length];
    private String pendingSelection;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);

        shizukuGrant = new ShizukuGrant(this, (success, message) -> {
            toast(message);
            refreshStatus();
        });
        pendingSelection = DnsPrefs.selection(this);
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        container = new LinearLayout(this);
        container.setOrientation(LinearLayout.VERTICAL);
        container.setPadding(dp(20), dp(26), dp(20), dp(30));
        scroll.addView(container);
        setContentView(scroll);

        TextView eyebrow = text("SAMSUNG GALAXY  •  УПРАВЛЕНИЕ СЕТЬЮ", 11, MUTED, true);
        eyebrow.setLetterSpacing(0.10f);
        add(eyebrow, 0);
        add(text("DNS Switch", 33, DARK, true), 2);
        add(text("Переключай частный DNS одним касанием из шторки.", 14, MUTED, false), 19);

        LinearLayout statusCard = card();
        addTo(statusCard, text("ТЕКУЩИЙ РЕЖИМ", 11, MUTED, true), 0);
        currentStatus = text("…", 24, DARK, true);
        addTo(statusCard, currentStatus, 9);
        currentDesc = text("", 13, MUTED, false);
        addTo(statusCard, currentDesc, 3);
        toggleButton = button("Включить DNS", true);
        addTo(statusCard, toggleButton, 18);
        toggleButton.setOnClickListener(v -> toggleDns());
        add(statusCard, 0);

        setupCard = card();
        addTo(setupCard, text("ОДИН РАЗ: ДОСТУП ЧЕРЕЗ SHIZUKU", 11, BLUE, true), 0);
        addTo(setupCard, text("Shizuku должен быть запущен. Нажми кнопку ниже и подтверди разрешение. Других приложений устанавливать не нужно.",
                14, DARK, false), 9);
        shizukuInfo = text("Проверка Shizuku…", 13, MUTED, false);
        addTo(setupCard, shizukuInfo, 10);
        shizukuButton = button("Выдать разрешение через Shizuku", true);
        shizukuButton.setOnClickListener(v -> {
            shizukuButton.setEnabled(false);
            shizukuGrant.start();
        });
        addTo(setupCard, shizukuButton, 12);
        addTo(setupCard, text("Если Shizuku не запущен: открой Shizuku → Запустить, затем вернись сюда.",
                12, MUTED, false), 11);
        add(setupCard, 14);

        TextView section = text("СЕРВЕР ПРИ ВКЛЮЧЕНИИ", 12, MUTED, true);
        section.setLetterSpacing(0.07f);
        add(section, 22);
        add(text("Выбери, что будет включаться кнопкой в шторке. Режим «Выключено» всегда отключает именно частный DNS.",
                13, MUTED, false), 7);

        LinearLayout optionsCard = card();
        optionsCard.setPadding(dp(11), dp(4), dp(11), dp(9));
        for (int i = 0; i < DnsPrefs.OPTIONS.length; i++) {
            final int idx = i;
            String[] option = DnsPrefs.OPTIONS[i];
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(5), dp(7), dp(2), dp(7));

            RadioButton radio = new RadioButton(this);
            radios[i] = radio;
            radio.setButtonTintList(android.content.res.ColorStateList.valueOf(BLUE));
            radio.setFocusable(false);
            radio.setClickable(false);
            row.addView(radio, new LinearLayout.LayoutParams(dp(47), dp(50)));

            LinearLayout nameBox = new LinearLayout(this);
            nameBox.setOrientation(LinearLayout.VERTICAL);
            nameBox.setGravity(Gravity.CENTER_VERTICAL);
            nameBox.addView(text(option[1], 15, DARK, true));
            if (DnsPrefs.AUTO.equals(option[0])) {
                nameBox.addView(text(option[2], 12, MUTED, false));
            }
            row.addView(nameBox, new LinearLayout.LayoutParams(0, dp(56), 1));
            row.setOnClickListener(v -> select(idx));
            optionsCard.addView(row);
            if (i < DnsPrefs.OPTIONS.length - 1) {
                View line = new View(this);
                line.setBackgroundColor(Color.rgb(238, 241, 247));
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(1));
                lp.setMargins(dp(50), 0, dp(4), 0);
                optionsCard.addView(line, lp);
            }
        }

        add(optionsCard, 12);

        Button saveButton = button("Сохранить выбранный DNS", true);
        saveButton.setOnClickListener(v -> saveSelection());
        add(saveButton, 13);

        LinearLayout tileCard = card();
        addTo(tileCard, text("КНОПКА В ШТОРКЕ", 11, BLUE, true), 0);
        addTo(tileCard, text("После установки добавь плитку «Частный DNS» в быстрые настройки Samsung. Одно касание — ВКЛ / ВЫКЛ.",
                14, DARK, false), 9);
        Button tileButton = button("Добавить в шторку", false);
        tileButton.setOnClickListener(v -> requestTile());
        addTo(tileCard, tileButton, 13);
        addTo(tileCard, text("Если кнопка добавления не сработает: открой шторку полностью → карандаш (Изменить) → найди «Частный DNS» → перетащи плитку.",
                12, MUTED, false), 9);
        add(tileCard, 20);
        add(text("Автоматический — использует DNS сети и может перейти на незашифрованный DNS. Выбранный провайдер использует системный DNS-over-TLS. Приложение не создаёт VPN и не проверяет доступность серверов.",
                12, MUTED, false), 15);

        select(indexOf(pendingSelection));
        refreshStatus();
    }

    @Override protected void onResume() {
        super.onResume();
        if (currentStatus != null) refreshStatus();
    }

    @Override protected void onDestroy() {
        if (shizukuGrant != null) shizukuGrant.release();
        super.onDestroy();
    }

    private void select(int idx) {
        pendingSelection = DnsPrefs.OPTIONS[idx][0];
        for (int i = 0; i < radios.length; i++) radios[i].setChecked(i == idx);
    }

    private int indexOf(String id) {
        for (int i = 0; i < DnsPrefs.OPTIONS.length; i++) {
            if (DnsPrefs.OPTIONS[i][0].equals(id)) return i;
        }
        return 0;
    }

    private void saveSelection() {
        String oldSelected = DnsPrefs.selection(this);
        DnsPrefs.save(this, pendingSelection);
        if (DnsControl.hasPermission(this) && DnsControl.enabled(this)) {
            try {
                DnsControl.setSelectedOn(this);
            } catch (Exception err) {
                DnsPrefs.save(this, oldSelected);
                toast("Не удалось применить DNS: " + err.getMessage());
                refreshStatus();
                return;
            }
        }
        toast("Выбрано: " + DnsPrefs.name(this));
        refreshStatus();
    }

    private void toggleDns() {
        if (!DnsControl.hasPermission(this)) {
            toast("Сначала выдай разрешение через Shizuku");
            return;
        }
        try {
            if (DnsControl.enabled(this)) DnsControl.setOff(this);
            else DnsControl.setSelectedOn(this);
            refreshStatus();
        } catch (Exception err) {
            toast("Ошибка: " + err.getMessage());
        }
    }

    private void refreshStatus() {
        boolean permission = DnsControl.hasPermission(this);
        boolean enabled = DnsControl.enabled(this);
        currentStatus.setText(enabled ? "DNS включён" : "DNS выключен");
        currentDesc.setText("Сейчас: " + DnsControl.status(this));
        toggleButton.setText(enabled ? "Выключить DNS" : "Включить DNS");
        toggleButton.setEnabled(permission);
        toggleButton.setAlpha(permission ? 1f : 0.45f);
        setupCard.setVisibility(permission ? View.GONE : View.VISIBLE);
        if (!permission && shizukuInfo != null) {
            try {
                shizukuInfo.setText(rikka.shizuku.Shizuku.pingBinder() ?
                        "Shizuku запущен ✅" : "Shizuku не запущен");
            } catch (Throwable ignored) { shizukuInfo.setText("Не удалось проверить Shizuku"); }
            shizukuButton.setEnabled(true);
        }
        DnsControl.notifyTile(this);
    }

    private void requestTile() {
        if (Build.VERSION.SDK_INT >= 33) {
            try {
                StatusBarManager manager = getSystemService(StatusBarManager.class);
                if (manager != null) {
                    manager.requestAddTileService(
                            new ComponentName(this, DnsTileService.class),
                            "Частный DNS",
                            Icon.createWithResource(this, R.drawable.ic_dns_tile),
                            getMainExecutor(),
                            result -> {
                                if (result == StatusBarManager.TILE_ADD_REQUEST_RESULT_TILE_ADDED) {
                                    toast("Плитка добавлена в шторку");
                                } else {
                                    toast("Добавьте плитку через редактирование шторки");
                                }
                            });
                    return;
                }
            } catch (Exception ignored) { /* Samsung may not support the prompt. */ }
        }
        toast("Откройте редактирование шторки и добавьте «Частный DNS»");
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
    }

    private LinearLayout card() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setBackground(shape(WHITE, 22, Color.rgb(232, 237, 248)));
        box.setPadding(dp(18), dp(18), dp(18), dp(18));
        box.setElevation(dp(2));
        return box;
    }

    private GradientDrawable shape(int color, int radius, int strokeColor) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        if (strokeColor != 0) d.setStroke(dp(1), strokeColor);
        return d;
    }

    private TextView text(String s, int sp, int color, boolean bold) {
        TextView tv = new TextView(this);
        tv.setText(s);
        tv.setTextSize(sp);
        tv.setTextColor(color);
        tv.setLineSpacing(dp(2), 1f);
        if (bold) tv.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return tv;
    }

    private Button button(String s, boolean primary) {
        Button btn = new Button(this);
        btn.setText(s);
        btn.setTextSize(14);
        btn.setAllCaps(false);
        btn.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        btn.setTextColor(primary ? WHITE : BLUE);
        btn.setBackground(shape(primary ? BLUE : Color.rgb(235, 240, 255), 14, 0));
        btn.setMinHeight(dp(49));
        btn.setPadding(dp(12), 0, dp(12), 0);
        return btn;
    }

    private void add(View view, int top) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(top);
        container.addView(view, lp);
    }

    private void addTo(LinearLayout parent, View view, int top) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(top);
        parent.addView(view, lp);
    }

    private int dp(float n) { return (int) (n * getResources().getDisplayMetrics().density + 0.5f); }
}
