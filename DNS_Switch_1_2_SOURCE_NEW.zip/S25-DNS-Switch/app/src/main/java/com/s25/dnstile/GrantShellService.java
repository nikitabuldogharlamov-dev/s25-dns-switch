package com.s25.dnstile;

import android.os.Binder;
import android.os.Parcel;
import android.os.RemoteException;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

/** Shizuku UserService, executed as the ADB shell user after explicit consent.
 * Deliberately supports ONLY the fixed permission grant to this app.
 */
public final class GrantShellService extends Binder {
    public static final int GRANT = IBinderTransactionCode.GRANT;
    private static final String DESCRIPTOR = "com.s25.dnstile.GrantShellService";
    private static final String[] COMMAND = {
            "/system/bin/pm", "grant", "com.s25.dnstile",
            "android.permission.WRITE_SECURE_SETTINGS"
    };

    public GrantShellService() { attachInterface(null, DESCRIPTOR); }

    @Override protected boolean onTransact(int code, Parcel data, Parcel reply, int flags)
            throws RemoteException {
        if (code == GRANT) {
            data.enforceInterface(DESCRIPTOR);
            int exit = -1;
            String output;
            try {
                Process proc = new ProcessBuilder(COMMAND).redirectErrorStream(true).start();
                ByteArrayOutputStream bytes = new ByteArrayOutputStream();
                try (InputStream in = proc.getInputStream()) {
                    byte[] buf = new byte[2048];
                    int n;
                    while ((n = in.read(buf)) != -1 && bytes.size() < 64000) {
                        bytes.write(buf, 0, Math.min(n, 64000 - bytes.size()));
                    }
                }
                exit = proc.waitFor();
                output = new String(bytes.toByteArray(), StandardCharsets.UTF_8);
            } catch (Exception e) {
                output = e.toString();
            }
            reply.writeNoException();
            reply.writeInt(exit);
            reply.writeString(output);
            return true;
        }
        return super.onTransact(code, data, reply, flags);
    }

    /** Keep binder protocol internal to the app. */
    static final class IBinderTransactionCode { static final int GRANT = FIRST_CALL_TRANSACTION; }
}
