package com.s25.dnstile;

import android.app.Activity;
import android.content.ComponentName;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.os.IBinder;
import android.os.Parcel;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import rikka.shizuku.Shizuku;

/** One-time secure-settings grant, requested from the running Shizuku service. */
public final class ShizukuGrant {
    private static final int REQ = 1001;
    private static final String DESCRIPTOR = "com.s25.dnstile.GrantShellService";
    public interface Callback { void onFinished(boolean success, String message); }

    private final Activity activity;
    private final Callback callback;
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private boolean pending;
    private boolean disposed;
    private Shizuku.UserServiceArgs args;
    private ServiceConnection connection;
    private final Shizuku.OnRequestPermissionResultListener permissionListener = (code, result) -> {
        if (code != REQ || !pending || disposed) return;
        if (result == PackageManager.PERMISSION_GRANTED) bind();
        else done(false, "Доступ к Shizuku не предоставлен");
    };

    public ShizukuGrant(Activity activity, Callback callback) {
        this.activity=activity;
        this.callback=callback;
        Shizuku.addRequestPermissionResultListener(permissionListener);
    }

    public void start() {
        if (disposed || pending) return;
        pending = true;
        try {
            if (!Shizuku.pingBinder()) {
                done(false, "Shizuku не запущен. Запусти его и вернись сюда.");
                return;
            }
            if (Shizuku.isPreV11()) {
                done(false, "Требуется Shizuku версии 11 или выше");
                return;
            }
            if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                bind();
            } else if (Shizuku.shouldShowRequestPermissionRationale()) {
                done(false, "Открой Shizuku и разреши доступ для DNS Switch");
            } else {
                Shizuku.requestPermission(REQ);
            }
        } catch (Exception err) {
            done(false, "Ошибка Shizuku: " + err.getMessage());
        }
    }

    private void bind() {
        if (disposed) return;
        try {
            args = new Shizuku.UserServiceArgs(new ComponentName(activity, GrantShellService.class))
                    .daemon(false)
                    .processNameSuffix("dnsgrant")
                    .tag("dns_switch_grant_v1")
                    .version(1);
            connection = new ServiceConnection() {
                @Override public void onServiceConnected(ComponentName component, IBinder binder) {
                    worker.execute(() -> grantViaBinder(binder));
                }
                @Override public void onServiceDisconnected(ComponentName component) {
                    if (pending) done(false, "Shizuku потерял соединение");
                }
            };
            Shizuku.bindUserService(args, connection);
        } catch (Exception err) { done(false, "Не удалось подключиться к Shizuku: " + err.getMessage()); }
    }

    private void grantViaBinder(IBinder binder) {
        Parcel data=Parcel.obtain(), reply=Parcel.obtain();
        boolean success=false;
        String message;
        try {
            data.writeInterfaceToken(DESCRIPTOR);
            if (!binder.transact(GrantShellService.GRANT,data,reply,0))
                throw new IllegalStateException("Shizuku не выполнил команду");
            reply.readException();
            int exit=reply.readInt();
            String output=reply.readString();
            success=exit==0;
            message=success ? "Разрешение выдано" :
                    "Команда завершилась с ошибкой " + exit + ": " + (output==null?"":output.trim());
        } catch (Exception err) {
            message="Ошибка запроса: " + err.getMessage();
        } finally { data.recycle(); reply.recycle(); }
        final boolean result=success;
        final String note=message;
        activity.runOnUiThread(() -> {
            if (disposed || !pending) return;
            if (result && !DnsControl.hasPermission(activity))
                done(false,"Команда выполнена, но Android не подтвердил разрешение");
            else done(result,note);
        });
    }

    private void done(boolean success, String message) {
        if (disposed || !pending) return;
        pending=false;
        // Do not call ServiceConnection.onDisconnected after successful completion.
        if (args!=null && connection!=null) {
            try { Shizuku.unbindUserService(args,connection,true); }
            catch(Exception ignored) { }
            args=null; connection=null;
        }
        callback.onFinished(success,message);
    }

    public void release() {
        disposed=true;
        Shizuku.removeRequestPermissionResultListener(permissionListener);
        worker.shutdownNow();
        if (args!=null && connection!=null) {
            try { Shizuku.unbindUserService(args,connection,true); }
            catch(Exception ignored) { }
        }
    }
}
