package com.s25.dnstile;

import android.content.Context;
import android.content.SharedPreferences;

/** Exactly six user-selected DNS-over-TLS hosts plus Android automatic mode. */
public final class DnsPrefs {
    public static final String AUTO = "auto";

    public static final String[][] OPTIONS = {
            {AUTO, "Автоматический", "DNS сети"},
            {"comss_one", "dns.comss.one", "dns.comss.one"},
            {"comss_control", "comss.dns.controld.com", "comss.dns.controld.com"},
            {"geohide", "dns.geohide.ru", "dns.geohide.ru"},
            {"xbox", "xbox-dns.ru", "xbox-dns.ru"},
            {"dns_ai", "dns.dns-ai.ru", "dns.dns-ai.ru"},
            {"webshift", "d.webshiftvpn.ru", "d.webshiftvpn.ru"}
    };

    private DnsPrefs() { }

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences("dns_settings", Context.MODE_PRIVATE);
    }

    public static String selection(Context c) {
        String s = prefs(c).getString("selected", AUTO);
        for (String[] option : OPTIONS) {
            if (option[0].equals(s)) return s;
        }
        return AUTO;
    }

    public static void save(Context c, String selection) {
        boolean found = false;
        for (String[] option : OPTIONS) {
            if (option[0].equals(selection)) { found = true; break; }
        }
        prefs(c).edit().putString("selected", found ? selection : AUTO).apply();
    }

    public static String host(Context c) {
        String selected = selection(c);
        for (String[] option : OPTIONS) {
            if (option[0].equals(selected)) {
                return AUTO.equals(selected) ? "" : option[2];
            }
        }
        return "";
    }

    public static String name(Context c) {
        String selected = selection(c);
        for (String[] option : OPTIONS) {
            if (option[0].equals(selected)) return option[1];
        }
        return "Автоматический";
    }
}
